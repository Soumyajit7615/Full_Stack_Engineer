﻿namespace AuthenticationMicroservice.Models
{
    public class Token
    {
        public string token { get; set; }
        public int Id { get; set; }
    }
}
