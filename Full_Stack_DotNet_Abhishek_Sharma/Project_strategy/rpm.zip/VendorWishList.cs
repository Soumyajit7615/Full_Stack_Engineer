﻿using RetailProductManagement.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace RetailProductManagement.Models
{
    public class VendorWishList
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int WishId { get; set; }
        
        [ForeignKey("UserId")]
        public int UserId { get; set; }
        
        [ForeignKey("ProductId")]
        public int ProductId { get; set; }

        [DisplayName("Quantity")]
        [Required(ErrorMessage = "Quantity cannot be empty")]
        public int Quantity { get; set; }
        
        [Required]
        public DateTime DateAddedToWishList { get; set; }

        public virtual UserDetail UserDetail { get; set; }
        public virtual Product Product { get; set; }
    }
}