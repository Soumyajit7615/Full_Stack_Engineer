﻿namespace RetailProductManagement.Models
{
    public class OrderDetail
    {
    }
}