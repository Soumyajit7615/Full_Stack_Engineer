﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace RetailProductManagement.Controllers
{
    public class UserDetail
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        //[Required(ErrorMessage = "UserId should not be blank")]
        public int UserId { get; set; }
        
        [ForeignKey("UserType")]
        //[Required(ErrorMessage = "User Type should not be blank")]
        public string UserType { get; set; }
        
        [DisplayName("FName")]
        [StringLength(30, MinimumLength = 5)]//length
        [Required(ErrorMessage = "First Name can`t be blank")]
        public string FName { get; set; }
        
        [DisplayName("LName")]
        [StringLength(30, MinimumLength = 5)]//length
        [Required(ErrorMessage = "Last Name can`t be blank")]
        public string LName { get; set; }
        
        [StringLength(30, MinimumLength = 8)]//length
        [DisplayName("UserName")]
        [Required(ErrorMessage = "User Name can`t be blank")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Date of Birth can`t be blank")]
        public DateTime Dob { get; set; }
        //[StringLength(6, MinimumLength = 4)]//length

        [Required(ErrorMessage = "Please select gender")]
        public string Gender { get; set; }
        
        [RegularExpression(@"^\[0-9]{3}\ [0-9]{3}-[0-9]{4}$")]//check reg expression_
        [Required(ErrorMessage = "Enter Correct Phone Number")]
        public string PhoneNumber { get; set; }
        
        [DisplayName("Email")]
        [Required(ErrorMessage = "Enail id can`t be blank")]
        public string Email { get; set; }
        
        [DisplayName("Password")]
        [Required(ErrorMessage = "Password can`t be blank")]
        public string Password { get; set; }
        
        [ForeignKey("SqId")]
        [Required(ErrorMessage = "Select Security Question")]
        public int SqId { get; set; }

        [StringLength(30, MinimumLength = 3)]
        [Required(ErrorMessage ="Security answer cannot be empty")]
        public string SqAns { get; set; }

      
        public virtual ICollection<UserDetail> UserDetails { get; set; }
    }
}