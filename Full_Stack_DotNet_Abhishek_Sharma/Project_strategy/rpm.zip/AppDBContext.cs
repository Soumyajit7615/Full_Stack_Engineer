﻿using RetailProductManagement.Controllers;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace RetailProductManagement.Models
{
    public class AppDBContext:DbContext
    {
        public AppDBContext() : base("name=RetailApp") { 
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<BillDetail> BillDetails { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Contact> Contacts { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<SecurityQuestion> SecurityQuestions { get; set; }
        public DbSet<UserDetail> UserDetails { get; set; }
        public DbSet<UserType> UserTypes { get; set; }
        public DbSet<VendorFeedBack> VendorFeedBacks { get; set; }
        public DbSet<VendorWishList> VendorWishLists { get; set; }

    }
}