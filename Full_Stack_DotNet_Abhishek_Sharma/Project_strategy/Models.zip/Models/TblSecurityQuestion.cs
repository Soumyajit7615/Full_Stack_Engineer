﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PolicyAdminMVC
{
    public class TblSecurityQuestion
    {
        [Key]
        public int SqId { get; set; }

        public string Questions { get; set; }

        // navigation property 
        public virtual ICollection<TblUser> TblUsers { get; set; }

    }
}
