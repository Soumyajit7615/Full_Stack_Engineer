﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PolicyAdminMVC
{
    public class BusinessesType
    {
        [Key]
        public int BtId { get; set; }

        public string Businesses_Type { get; set; }   // excel sheet contains BusinessesTypes..

        // navigation Property
        public virtual ICollection<PropertyDescription> PropertyDescriptions { get; set; }

    }
}
