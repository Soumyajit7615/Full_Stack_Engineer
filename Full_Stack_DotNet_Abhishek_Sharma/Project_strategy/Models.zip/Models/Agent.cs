﻿using PolicyAdminMVC.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace PolicyAdminMVC
{
    public class Agent
    {
        [Key]
        public int AgentId { get; set; }

        public string AgentName { get; set; }

        public int PolicyTenure { get; set; }

        public string AcceptedQuote { get; set; }


        // navigation Property
        public virtual ICollection<ConsumerPortfolio> ConsumerPortfolios { get; set; }
        
        public virtual ICollection<PolicyDetail> PolicyDetails { get; set; }

        

    }
}
