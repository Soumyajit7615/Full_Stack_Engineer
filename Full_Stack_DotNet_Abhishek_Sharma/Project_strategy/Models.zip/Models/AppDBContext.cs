﻿using PolicyAdminMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.EntityFrameworkCore;

namespace PolicyAdminMVC.Models
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Seed();


            modelBuilder.Entity<PolicyDetail>()
              .HasOne<TblUser>(s => s.TblUser)
              .WithMany(ta => ta.PolicyDetails)
              .HasForeignKey(u => u.UserId)
              .OnDelete(DeleteBehavior.Restrict);

            
            modelBuilder.Entity<ConsumerPortfolio>()
              .HasOne<PolicyDetail>(s => s.PolicyDetail)
              .WithMany(ta => ta.ConsumerPortfolios)
              .HasForeignKey(u => u.PdId)
              .OnDelete(DeleteBehavior.Restrict);
        }

    

        public virtual DbSet<TblUser> TblUsers { get; set; }
        public virtual DbSet<TblAddress> TblAddresses { get; set; }
        public virtual DbSet<PolicyDetail> PolicyDetails { get; set; }
        public virtual DbSet<ConsumerPortfolio> ConsumerPortfolios { get; set; }
        public virtual DbSet<PropertyDescription> PropertyDescriptions { get; set; }
        public virtual DbSet<Agent> Agents { get; set; }

        public virtual DbSet<TblCategory> TblCategories { get; set; }
        public virtual DbSet<TblSecurityQuestion> TblSecurityQuestions { get; set; }
        public virtual DbSet<Status> Statuses { get; set; }
        public virtual DbSet<BusinessesType> BusinessesTypes { get; set; }
        public virtual DbSet<Property> Properties { get; set; }
        public virtual DbSet<BusinessInsurancePolicy> BusinessInsurancePolicies { get; set; }
        public virtual DbSet<PropertyRule> PropertyRules { get; set; }

    }

}
