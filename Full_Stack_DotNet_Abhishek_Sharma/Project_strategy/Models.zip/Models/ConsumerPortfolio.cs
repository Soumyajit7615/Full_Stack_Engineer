﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PolicyAdminMVC
{
    public class ConsumerPortfolio
    {
        [Key]
        public int CpId { get; set; }

        [ForeignKey("TblUser")]
        public int UserId { get; set; }

        [ForeignKey("PolicyDetail")]
        public int PdId { get; set; }  
        
        [ForeignKey("Agent")]
        public int AgentId { get; set; }

        public DateTime CommenceDate { get; set; }

        public int Duration { get; set; }

        public DateTime MaturityDate { get; set; }

        //this is also a foreign key
        //mark it later
        public string MaturityStatus { get; set; }

        // navigation property 

        public virtual TblUser TblUser { get; set; }

        public virtual PolicyDetail PolicyDetail { get; set; }

        public virtual Agent Agent { get; set; }
    }

}
