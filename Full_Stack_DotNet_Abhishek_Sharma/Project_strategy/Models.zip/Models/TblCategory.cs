﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PolicyAdminMVC
{
    public class TblCategory
    {

        // here we will write the columns of the table 
        [Key]
        public int CatId { get; set; }

        public string Category { get; set; }

        // navigation property 
        public virtual ICollection<TblUser> TblUsers { get; set; }

    }
}
