﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PolicyAdminMVC
{
    public class PolicyDetail
    {
        [Key]
        public int PdId { get; set; }

        [ForeignKey("TblUser")]
        public int UserId { get; set; }

        [ForeignKey("PropertyDescription")]
        public int PropId { get; set; }

        [ForeignKey("PropertyRule")]
        public int PropertyRuleId { get; set; }

        [ForeignKey("BusinessInsurancePolicy")]
        public int BipId { get; set; }

        [ForeignKey("Agent")]
        public int AgentId { get; set; }  // also written as UserId in Excel

        public string AgentName { get; set; }

        public int SumAssured { get; set; }

        public int Duration { get; set; } // also Written as year in Excel

        public string Quote { get; set; } // also written as premium in Excel

        public int StatusId { get; set; } // also written as Accepted Quotes in Excel

        // navigation Property 

        public virtual ICollection<ConsumerPortfolio> ConsumerPortfolios { get; set; }

        public virtual TblUser TblUser { get; set; }

        public virtual PropertyDescription PropertyDescription { get; set; }

        public virtual PropertyRule PropertyRule { get; set; }

        public virtual BusinessInsurancePolicy BusinessInsurancePolicy { get; set; }

        public virtual Agent Agent { get; set; }




    }
}
