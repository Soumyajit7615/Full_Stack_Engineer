﻿using PolicyAdminMVC.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace PolicyAdminMVC
{
    public class TblUser
    {
        // here we will add the columns of the Table
        [Key]
        public int UserId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Gender { get; set; }

        public string ContactNo { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        [ForeignKey("TblCategory")]
        public int CatId { get; set; }

        [ForeignKey("Status")]
        public int StatusId { get; set; }

        [ForeignKey("TblSecurityQuestion")]
        public int SqId { get; set; }

        public string Answer { get; set; }

        // navigation property

        public virtual ICollection<TblAddress> TblAddresses { get; set; }
        public virtual TblCategory TblCategory { get; set; }
        public virtual Status Status { get; set; }
        public virtual TblSecurityQuestion TblSecurityQuestion { get; set; }

        public virtual ICollection<PolicyDetail> PolicyDetails { get; set; }

        // confirm this later 
        public virtual ICollection<ConsumerPortfolio> ConsumerPortfolios { get; set; }
    }
}
