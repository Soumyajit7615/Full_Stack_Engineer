﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PolicyAdminMVC
{
    public class PropertyDescription
    {
        [Key]
        public int PropId { get; set; }

        [ForeignKey("TblAddress")]
        public int AddId { get; set; }

        [ForeignKey("Property")]
        public int ProperyId { get; set; }

        [ForeignKey("BusinessesType")]
        public int BtId { get; set; }

        public int BuldingSqFt { get; set; }

        public int BuldingStorey { get; set; }

        public int BuldingAge { get; set; }


        // request entries A|P|C
        public string Request { get; set; }

        // navigation Property 
        public virtual TblAddress TblAddress { get; set; }

        public virtual BusinessesType BusinessesType { get; set; }

        public virtual Property Property { get; set; }

        public virtual ICollection<PolicyDetail> PolicyDetails { get; set; }
    }
}
