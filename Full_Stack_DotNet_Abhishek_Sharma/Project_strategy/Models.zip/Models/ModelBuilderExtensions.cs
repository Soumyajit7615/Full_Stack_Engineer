﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace PolicyAdminMVC.Models
{
    public static class ModelBuilderExtensions

    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblSecurityQuestion>().HasData(
            new TblSecurityQuestion() { SqId = 1, Questions = "What is your mother's maiden name?" },
            new TblSecurityQuestion() { SqId = 2, Questions = "What is the name of your first pet?" },
            new TblSecurityQuestion() { SqId = 3, Questions = "What was your first car?" },
            new TblSecurityQuestion() { SqId = 4, Questions = "What elementary school did you attend?" },
            new TblSecurityQuestion() { SqId = 5, Questions = "What is the name of the town where you were born?" },
            new TblSecurityQuestion() { SqId = 6, Questions = "When you were young, what did you want to be when you grew up?" },
            new TblSecurityQuestion() { SqId = 7, Questions = "Who was your childhood hero?" },
            new TblSecurityQuestion() { SqId = 8, Questions = "Where was your best family vacation as a kid?" }
            );
        }
    }
}
