﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PolicyAdminMVC
{
    public class Property
    {
        [Key]
        public int PropertyId { get; set; }

        public string PropertyType { get; set; }

        // here is the navigation Property

        public virtual ICollection<PropertyDescription> PropertyDescriptions { get; set; }
        public virtual PropertyRule PropertyRule { get; set; }


    }
}
