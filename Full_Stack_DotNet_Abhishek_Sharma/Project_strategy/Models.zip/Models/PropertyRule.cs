﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PolicyAdminMVC
{
    public class PropertyRule
    {
        [Key]
        public int PropertyRuleId { get; set; }

        // this is specified as property_type_id in excel 
        // foreign key having relationship with the primary key of the property file
        [ForeignKey("Property")]
        public int PropertyId { get; set; }   

        public string AboutRule { get; set; }

        // navigation Property 
        public virtual ICollection<PolicyDetail> PolicyDetails { get; set; }
        public virtual ICollection<Property> Properties { get; set; }


    }
}
