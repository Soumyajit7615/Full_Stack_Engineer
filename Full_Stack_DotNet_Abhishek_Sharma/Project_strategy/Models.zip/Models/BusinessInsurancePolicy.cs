﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PolicyAdminMVC
{
    public class BusinessInsurancePolicy
    {
        [Key]
        public int BipId { get; set; }

        public string PolicyType { get; set; }

        // navigation Property

        public virtual ICollection<PolicyDetail> PolicyDetails { get; set; }


    }
}
