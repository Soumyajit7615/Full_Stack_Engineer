﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PolicyAdminMVC
{
    public class TblAddress
    {
        [Key]
        public int AddId { get; set; }

        [ForeignKey("TblUser")]
        public int UserId { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string Locality { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public int Pincode { get; set; }

        // navigation property 
        public virtual TblUser TblUser { get; set; }
        public virtual ICollection<PropertyDescription> PropertyDescriptions { get; set; }

        


    }
}
