﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary2;
using NUnit.Framework;
using Moq;


namespace PlayerManager.Tests
{
    [TestFixture]
    public class Class1
    {
        [Test]
      
        public void ThrowExceptionTest()
        {
            var res = new Player("  ",12,"India",1);

            var play = new PlayerMapper();

            Assert.That(()=> Player.RegisterNewPlayer(" ", play),Throws.Exception.TypeOf<ArgumentException>());
        }
        [Test]
        public void TestforRegister()
        {
            var mock= new Mock<IPlayerMapper>();

            mock.Setup(x => x.IsPlayerNameExistsInDb(" ")).Returns(false);

            Assert.AreEqual(false, mock.Object.IsPlayerNameExistsInDb(" "));
        }
        [Test]
        public void AttributeTestName()
        {
            var mock = new Mock<IPlayerMapper>();

            var play = new Player("Ram", 12, "India", 1);

            Assert.AreEqual("Ram", play.Name);
        }
        [Test]
        public void AttributeTestAge()
        {
            var mock = new Mock<IPlayerMapper>();

            var play = new Player("Ram", 12, "India", 1);

            Assert.AreEqual(12, play.Age);
        }
        [Test]
        public void AttributeTestCountry()
        {
            var mock = new Mock<IPlayerMapper>();

            var play = new Player("Ram", 12, "India", 1);

            Assert.AreEqual("India", play.Country);
        }
        [Test]
        public void AttributeTestnoOfMatches()
        {
            var mock = new Mock<IPlayerMapper>();

            var play = new Player("Ram", 12, "India", 1);

            Assert.AreEqual(1, play.NoOfMatches);
        }
    }
}
