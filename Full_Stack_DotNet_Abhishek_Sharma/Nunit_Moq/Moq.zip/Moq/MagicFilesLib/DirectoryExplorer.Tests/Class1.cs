﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MagicFilesLib;
using Moq;
using NUnit.Framework;

namespace DirectoryExplorer.Tests
{
    [TestFixture]
    public class MagicFilesLibTest

    {
        private const string V = "1";
        private readonly string _file1 = "file.txt";
        private readonly string _file2 = "file2.txt";

        [Test]
        public void NotNullTest()
        {
            var mock = new Mock<IDirectoryExplorer>();

            mock.Setup(x => x.GetFiles(_file2)).Returns(new string[] { _file2 });


            Assert.That(mock.Object, Is.Not.Null);

        }
        [Test]
        public void CountTest()
        {

            var mock = new Mock<IDirectoryExplorer>();
            mock.Setup(x => x.GetFiles(_file1)).Returns(new string[] { V });


            Assert.AreEqual(new string[] {"1"},mock.Object.GetFiles(_file1));

        }
        [Test]
        public void ConatinsTest()
        {

            var mock = new Mock<IDirectoryExplorer>();
            mock.Setup(q => q.GetFiles(_file1)).Returns(new string[] { _file1 });


            Assert.AreEqual(new string[] {_file1}, mock.Object.GetFiles(_file1));



        }
    }
}
