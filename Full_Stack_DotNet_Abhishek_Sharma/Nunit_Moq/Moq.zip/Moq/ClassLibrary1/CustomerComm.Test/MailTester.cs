﻿
using CustomerCommLib;
using Moq;
using NUnit.Framework;

namespace CustomerComm.Test
{
    [TestFixture]
    public class MailTester
    {
        [Test]
        public void SendMailTest()
        {
            var mock = new Mock<IMailSender>();

            CustomerCom cust=new CustomerCom(mock.Object);

           mock.Setup(x => x.SendMail(It.IsAny<string>(), It.IsAny<string>())).Returns(true);

            Assert.AreEqual(cust.SendMailToCustomer(),true);
        }
    }
}
