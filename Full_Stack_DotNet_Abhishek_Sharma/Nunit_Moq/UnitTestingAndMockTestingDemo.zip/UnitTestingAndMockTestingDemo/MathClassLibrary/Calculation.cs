﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathClassLibrary
{
    //Unit testing means testing your code in isolated and automated way.

    public interface ICustomer
    {
        int CustomerCode { get; set; }
        string CustomerName { get; set; }
        double CustomerAmount { get; set; }

    }
    public interface IUser
    {
        int Id { get; set; }
        string Name { get; set; }


    }
    public class Calculation
    {
        public interface Mockable
        {
            bool DoSomething();
            string ReturnMessage();
        }
        public int AddTwoNumber(int x, int y)
        {
            return x + y;

        }

        public int MultiplicationTwoNumber(int x, int y)
        {
            return x * y;

        }

        public void SetPropertiesOfUser(IUser user)
        {
            user.Id = 5;
            user.Name = "SomeName";
        }

    }
}
