﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MathClassLibrary;
using Moq;

namespace MathUnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        Calculation c;

        [TestMethod]
        public void TestEqualityWithAdditioMethod()
        {
            //ARRANGE

            c = new Calculation();

            //ACT
            int result = c.AddTwoNumber(11, 22);

            //ASSERT
            Assert.AreEqual(33, result);

        }
        [TestMethod]
        public void TestNotEqualWithMultiMethod()
        {
            c = new Calculation();

            //ARRANGE


            //ACT
            int result = c.MultiplicationTwoNumber(11, 22);

            //ASSERT
            Assert.AreNotEqual(241, result);

        }

        [TestMethod]
        public void TestMoq()
        {
            //ARRANGE
            var mock = new Mock<Calculation.Mockable>();
            //ACT
            mock.Setup(x => x.DoSomething()).Returns(true); 
            var result = mock.Object.DoSomething(); //true
            //ASSERT
            Assert.AreEqual(true, result);
        }
        [TestMethod]
        public void TestMoqII()
        {
            //ARRANGE
            var mock = new Mock<Calculation.Mockable>();
            //ACT
            mock.Setup(x => x.ReturnMessage()).Returns("Hello");
            var result = mock.Object.ReturnMessage(); //true
            //ASSERT
            Assert.AreEqual("Hello", result);
        }

        [TestMethod]
        public void TestMoqInitializeProp()
        {

            var userMock = new Mock<IUser>().SetupAllProperties();

            // Invoke the code to test
            c = new Calculation();
            c.SetPropertiesOfUser(userMock.Object);

            // Validate properties have been set
            Assert.AreEqual(5, userMock.Object.Id);
            Assert.AreEqual("SomeName", userMock.Object.Name);

            // ViewBag.ID. ViewBag.Name 

        }




    }
}
