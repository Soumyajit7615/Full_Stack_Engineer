﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ASPMvcClientConsumeWEBApiDemo.Models
{
    public class Product
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductCode { get; set; }
        [Required(ErrorMessage = "Product name should not be blank")]
        public string ProductName { get; set; }
        [Required(ErrorMessage = "Product price should not be blank")]
        public decimal ProductPrice { get; set; }
    }
}
