﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASPMvcClientConsumeWEBApiDemo.Models;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Json;

namespace ASPMvcClientConsumeWEBApiDemo.Controllers
{
    public class ComputerProductsController : Controller
    {
        // GET: ComputerProductsController
        //http://localhost:34162/api/Products
        public async Task<IActionResult> Index()
        {
            List<Product> products = new List<Product>();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:34162/");
            HttpResponseMessage response = await client.GetAsync("api/Products");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
                products = JsonConvert.DeserializeObject<List<Product>>(results);
            }

            return View(products);
        }

        // GET: ComputerProductsController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            //http://localhost:34162/api/Products/1
            Product product = new Product();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:34162/");
            HttpResponseMessage response = await client.GetAsync($"api/Products/{id}");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                product = JsonConvert.DeserializeObject<Product>(result);
            }

            return View(product);
        }
        // GET: ComputerProductsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ComputerProductsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            //http://localhost:34162/api/Products/
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:34162/");
            var response = await client.PostAsJsonAsync("api/Products", product);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            return View();

        }
      
        // GET: ComputerProductsController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            //http://localhost:34162/api/Products/
            Product product = new Product();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:34162/");
            HttpResponseMessage response = await client.GetAsync($"api/Products/{id}");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                product = JsonConvert.DeserializeObject<Product>(result);
            }

            return View(product);
        }

        // POST: ComputerProductsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Product product)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:34162/");
            var response = await client.PutAsJsonAsync($"api/Products/{product.ProductCode}", product);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            return View();

        }



        // GET: ComputerProductsController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            //http://localhost:34162/api/Products/
            Product product = new Product();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:34162/");
            HttpResponseMessage response = await client.GetAsync($"api/Products/{id}");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                product = JsonConvert.DeserializeObject<Product>(result);
            }

            return View(product);
        }

        // POST: ComputerProductsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, IFormCollection collection)
        {

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:34162/");
            HttpResponseMessage response = await client.DeleteAsync($"api/Products/{id}");

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            return View();
        }
    }
}
