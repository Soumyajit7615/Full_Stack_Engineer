﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace AspMvcCoreWebAPICfDemo.Models
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                new Product() { ProductCode = 1, ProductName = "Speakers", ProductPrice = 30000.00m },
         new Product() { ProductCode = 2, ProductName = "Desktops", ProductPrice = 30000.00m },
         new Product() { ProductCode = 3, ProductName = "Laptops", ProductPrice = 25000.00m },
         new Product() { ProductCode = 4, ProductName = "Gaming PC's", ProductPrice = 60000.00m },
         new Product() { ProductCode = 5, ProductName = "Servers", ProductPrice = 100000.00m },
         new Product() { ProductCode = 6, ProductName = "Tablet", ProductPrice = 5000.00m },
         new Product() { ProductCode = 7, ProductName = "PC's Monitors", ProductPrice = 5000.00m },
         new Product() { ProductCode = 8, ProductName = "Memory", ProductPrice = 2500.00m },
         new Product() { ProductCode = 9, ProductName = "Printers", ProductPrice = 4000.00m },
         new Product() { ProductCode = 10, ProductName = "Projectors", ProductPrice = 30000.00m }
         );
        }
    }
}
