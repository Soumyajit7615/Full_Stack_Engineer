﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using aspmvcwebcoreuserprofilewithimageupload.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace aspmvcwebcoreuserprofilewithimageupload.Controllers
{
    public class UserProfilesWithImageUploadController : Controller
    {
        private readonly AppDBContext _context;
        private readonly IWebHostEnvironment _hostEnvironment;

        public UserProfilesWithImageUploadController(AppDBContext context, IWebHostEnvironment hostEnvironment)
        {
            _context = context;
            _hostEnvironment = hostEnvironment;
        }

        // GET: UserProfilesWithImageUpload
        public async Task<IActionResult> Index()
        {
            return View(await _context.UsersProfile.ToListAsync());
        }

        // GET: UserProfilesWithImageUpload/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clsUserProfile = await _context.UsersProfile
                .FirstOrDefaultAsync(m => m.UserId == id);
            if (clsUserProfile == null)
            {
                return NotFound();
            }

            return View(clsUserProfile);
        }

        // GET: UserProfilesWithImageUpload/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: UserProfilesWithImageUpload/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UserId,UserName,DOJ,Designation,ImageFile")] ClsUserProfile clsUserProfile)
        {
            if (ModelState.IsValid)
            {
                // a = a + 1
                //Save image to wwwroot/Upload
                string wwwRootPath = _hostEnvironment.WebRootPath;
                string fileName = Path.GetFileNameWithoutExtension(clsUserProfile.ImageFile.FileName);
                string extension = Path.GetExtension(clsUserProfile.ImageFile.FileName);
                clsUserProfile.ImageName = fileName = fileName + DateTime.Now.ToString("yyyymmssfff") + extension;
                string path = Path.Combine(wwwRootPath + "/Upload/", fileName);

                using (FileStream fileStream = new FileStream(path, FileMode.Create))
                {
                    await clsUserProfile.ImageFile.CopyToAsync(fileStream);
                }
                //Insert the record
                _context.Add(clsUserProfile);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(clsUserProfile);
        }

        // GET: UserProfilesWithImageUpload/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clsUserProfile = await _context.UsersProfile.FindAsync(id);
            if (clsUserProfile == null)
            {
                return NotFound();
            }
            return View(clsUserProfile);
        }

        // POST: UserProfilesWithImageUpload/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("UserId,ImageName,UserName,DOJ,Designation,ImageFile")] ClsUserProfile clsUserProfile)
        {
            if (id != clsUserProfile.UserId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                   
                    // Edit profile 
                    // Delete Existing Image from Upload folder
                    //delete images from wwwroot/Upload folder
                    string imagePath = Path.Combine(_hostEnvironment.WebRootPath, "Upload", clsUserProfile.ImageName);
                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                    // Assign updated image in database
                    string wwwRootPath = _hostEnvironment.WebRootPath;
                    string fileName = Path.GetFileNameWithoutExtension(clsUserProfile.ImageFile.FileName);
                    string extension = Path.GetExtension(clsUserProfile.ImageFile.FileName);
                    clsUserProfile.ImageName = fileName = fileName + DateTime.Now.ToString("yyyymmssfff") + extension;
                    string path = Path.Combine(wwwRootPath + "/Upload/", fileName);

                    using (FileStream fileStream = new FileStream(path, FileMode.Create))
                    {
                        await clsUserProfile.ImageFile.CopyToAsync(fileStream);
                    }


                    // Update record

                    _context.Update(clsUserProfile);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClsUserProfileExists(clsUserProfile.UserId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(clsUserProfile);
        }

        // GET: UserProfilesWithImageUpload/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clsUserProfile = await _context.UsersProfile
                .FirstOrDefaultAsync(m => m.UserId == id);
            if (clsUserProfile == null)
            {
                return NotFound();
            }

            return View(clsUserProfile);
        }

        // POST: UserProfilesWithImageUpload/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var clsUserProfile = await _context.UsersProfile.FindAsync(id);
            //delete images from wwwroot/Upload folder
            string imagePath = Path.Combine(_hostEnvironment.WebRootPath, "Upload", clsUserProfile.ImageName);
            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }


            _context.UsersProfile.Remove(clsUserProfile);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClsUserProfileExists(int id)
        {
            return _context.UsersProfile.Any(e => e.UserId == id);
        }
    }
}
