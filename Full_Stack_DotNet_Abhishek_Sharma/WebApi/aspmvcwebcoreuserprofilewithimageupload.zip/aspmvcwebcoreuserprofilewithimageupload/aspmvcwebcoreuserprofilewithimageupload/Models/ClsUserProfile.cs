﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace aspmvcwebcoreuserprofilewithimageupload.Models
{
    public class ClsUserProfile
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [DisplayName("UserId")]
        public int UserId { get; set; }

        [DisplayName("User Name")]
        [Required(ErrorMessage = "User name should not be blank")]
        public string UserName { get; set; }

        [DisplayName("DOJ")]
        [Required(ErrorMessage = "DOJ should not be blank")]
        [Column("DOJ", TypeName = "DateTime2")]
        public DateTime DOJ { get; set; }

        [Required(ErrorMessage = "Designation should not be blank")]
        [Column("Designation", TypeName = "nvarchar(50)")]
        public string Designation { get; set; }
        [DisplayName("Image Name")]
        [Required(ErrorMessage = "ImageName should not be blank")]
        [Column("ImageName", TypeName = "nvarchar(100)")]
        public string ImageName { get; set; } = "MyImage";

        [NotMapped]
        [DisplayName("Image Name")]
        public IFormFile ImageFile { get; set; }
    }
}
