import React from "react";
const NotFound = () => {
  return (
    <div className="not-found">
      <div>
        <h1 className="display-1 text-danger">Page Not Found</h1>
      </div>
    </div>
  );
};
export default NotFound;
