import React from "react";

const About = () => {
  return (
    <div className="container">
      <div className="py-4">
        <h1 className="Display-3">About Page</h1>
        <aside className="lead text-justify">
          Culpa laboris do irure commodo. Ipsum sint incididunt deserunt eiusmod
          eu excepteur adipisicing excepteur. Duis ea adipisicing occaecat qui.
          Enim proident reprehenderit dolore veniam. Exercitation nostrud dolor
          nisi enim sit laboris ullamco fugiat. Enim officia cupidatat ad ex
          minim laboris irure minim nostrud quis consequat. In cillum
          consectetur dolor irure incididunt amet cupidatat mollit magna
          consectetur deserunt adipisicing. Aute nulla velit tempor laboris amet
          duis qui id. Pariatur sint incididunt veniam labore ullamco in
          consectetur dolor consequat ut quis. Ea laborum nisi et nisi eu
          proident sit et et cupidatat culpa adipisicing. Pariatur ea aute
          proident exercitation minim reprehenderit culpa est irure proident
          Lorem ut. Mollit ad tempor adipisicing amet do qui officia aliquip
          quis. Mollit non amet ad laboris minim anim. In proident est quis elit
          do ullamco aliquip labore et exercitation. Aliquip consectetur
          voluptate ad labore est tempor ut eiusmod. Exercitation eiusmod esse
          excepteur magna incididunt voluptate exercitation minim culpa ad. Nisi
          ex ullamco qui non labore magna id. Irure aute duis Lorem labore
          laborum elit aliquip nisi. Ut anim reprehenderit non non est velit
          cupidatat non ullamco incididunt adipisicing. Do minim cillum duis
          aute fugiat irure ea excepteur cillum est est velit. Occaecat do ut ex
          labore. Ea consectetur laboris aliquip eu labore excepteur aliquip
          reprehenderit enim dolore. Aute commodo ex exercitation consequat
          excepteur pariatur dolore ullamco adipisicing labore nostrud excepteur
          in. Dolor irure magna voluptate exercitation quis dolor labore ea.
          Fugiat veniam consectetur voluptate incididunt reprehenderit tempor
          aute nulla excepteur et fugiat nostrud. Lorem laboris excepteur id ut
          ipsum excepteur culpa. Amet eu ut tempor aliquip cillum irure id.
          Occaecat sunt consequat est nulla anim sint laborum ad ad eiusmod
          occaecat tempor. Anim sunt duis velit esse exercitation. Dolor mollit
          deserunt pariatur aute excepteur duis eiusmod magna. Anim ex occaecat
          incididunt esse non. Voluptate proident esse commodo sint. Adipisicing
          aliqua occaecat ipsum do amet magna est anim minim in veniam nostrud
          duis minim. Cupidatat occaecat sint cillum culpa occaecat. Esse veniam
          enim tempor ut et duis elit irure. Culpa laboris velit nisi anim
          exercitation enim sunt Lorem aliqua laboris. Ipsum adipisicing do enim
          veniam commodo qui tempor sint eu exercitation sit commodo. Do amet
          nostrud culpa nisi. Ipsum culpa ut eu quis non quis ea commodo sunt
          eiusmod laborum ex ex.
        </aside>
      </div>
    </div>
  );
};

export default About;
