﻿Instruction to run this demo project:
- Attach SchoolDB.mdf in your local MS SQL Server 2012 or above
- Verify the connection string in App.config and make sure that it is pointing to your local DB server. 
- You may delete School.edmx and add a new Entity Data Model named 'School'.