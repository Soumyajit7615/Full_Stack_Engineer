﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDatabaseFirstWithRelationalTables
{
    class Program
    {
        static void Main(string[] args)
        {
            CTSGN22ADMDNFS001Entities entities = new CTSGN22ADMDNFS001Entities();
            //Console.WriteLine("How to Inner join with query expression");

            //var SelEmpWithDept = from e in entities.Employees
            //                     join d in entities.Departments on e.DeptID equals d.DeptId
            //                     select new { EmpID = e.EmpID, EmpName = e.EmpName, CourseDuration = e.CourseDuration, DeptID = e.DeptID, DeptName = d.DeptName, DeptLoc = d.DeptLoc };
            //Console.WriteLine("EmpID EmpName CourseDuration DeptID DeptName DeptLoc");
            //foreach (var item in SelEmpWithDept)
            //{
            //    Console.WriteLine(item.EmpID + " " + item.EmpName + " " + item.CourseDuration + " " + item.DeptID + " " + item.DeptName + " " + item.DeptLoc);
            //}

            //Console.WriteLine("Inner Join Using LINQ With Lambda");

            //var SelectEmpWithDept = entities.Employees.Join(entities.Departments, e => e.EmpID, d => d.DeptId, (e, d) => new
            //{ EmpID = e.EmpID, EmpName = e.EmpName, CourseDuration = e.CourseDuration, DeptID = e.DeptID, DeptName = d.DeptName, DeptLoc = d.DeptLoc });

            //foreach (var item in SelectEmpWithDept)
            //{
            //    Console.WriteLine(item.EmpID + " " + item.EmpName + " " + item.CourseDuration + " " + item.DeptID + " " + item.DeptName + " " + item.DeptLoc);
            //}

            

            Console.WriteLine("BY USING ID PROPERTIES");
           // Department department = entities.Departments.FirstOrDefault(d => d.DeptId == 1);


            //entities.Employees.Add(new Employee()
            //{
            //    EmpName = "Sneha Dey",
            //    DeptID = department.DeptId,
            //    CourseDuration = 40
            //});
            //entities.SaveChanges();

            Console.WriteLine("BY USING NEVIGATION PROPERTIES EMPLOYEE.DEPARTMENT");
            //Department department = entities.Departments.FirstOrDefault(d => d.DeptId == 1);
            //entities.Employees.Add(new Employee()
            //{
            //    EmpName = "Soumyajit Das",
            //    Department = department,
            //    CourseDuration = 40

            //});
            //entities.SaveChanges();
            Console.WriteLine("BY USING NEVIGATION PROPERTIES DEPARTMENT.EMPLOYEE");
            //Department department = entities.Departments.FirstOrDefault(d => d.DeptId == 1);

            //department.Employees.Add(new Employee()
            //{
            //    EmpName = "Aniket",
            //    CourseDuration = 40
            //});

            //entities.SaveChanges();



            //UPDATE
            //Employee employee = entities.Employees.FirstOrDefault(e => e.EmpID == 1022);
            //employee.EmpName = "Aniket Mohapatra";
            //entities.SaveChanges();

            //DELETE
            //Employee employee = entities.Employees.FirstOrDefault(e => e.EmpID == 1007);
            //entities.Employees.Remove(employee);

            //DELETE ON DELETE CASCADE
            //Department department = entities.Departments.FirstOrDefault(d => d.DeptId == 5);
            //entities.Departments.Remove(department);
            //entities.SaveChanges();




        }
    }
}
