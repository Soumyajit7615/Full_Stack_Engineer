﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace EFDatabaseFirstCalingStoredProcedueDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            CTSGN22ADMDNFS001Entities context = new CTSGN22ADMDNFS001Entities();

            // var data = context.Database.ExecuteSqlCommand("SPSelectEmployees");
            var data = context.SPSelectEmployees();

            foreach (var item in data)
            {
                Console.WriteLine(item.EmpID+" "+item.EmpName+" "+item.DeptID+" "+item.CourseDuration);
            }



            Employee employee = new Employee()
            {
                EmpName = "Yaswanth",
                DeptID = 1,
                CourseDuration = 40

            };

            SqlParameter[] parameters = new SqlParameter[]{
                new SqlParameter("@EmpName",employee.EmpName),
                new SqlParameter("@DeptID",employee.DeptID),
                new SqlParameter("@CourseDuration",employee.CourseDuration)
           };
            //ADD EMPLOYEE 
            //var data = context.Database.ExecuteSqlCommand("SPAddEmployees @EmpName , @DeptID , @CourseDuration", parameters);

            //UPDATE EMPLOYEE

            employee = new Employee()
            {
                EmpID = 1024,
                EmpName = "Yaswanth Reddy",
                DeptID = 1,
                CourseDuration = 40

            };
            //UPDATE EMPLOYEE

            // SqlParameter[] parameters2 = new SqlParameter[]{
            //     new SqlParameter("@EmpID",employee.EmpID),
            //     new SqlParameter("@EmpName",employee.EmpName),
            //     new SqlParameter("@DeptID",employee.DeptID),
            //     new SqlParameter("@CourseDuration",employee.CourseDuration)
            //};
            // var data = context.Database.ExecuteSqlCommand("SPUpdateEmployee @EmpID , @EmpName , @DeptID , @CourseDuration", parameters2);

            //DELETE EMPLOYEE

            //var data = context.Database.ExecuteSqlCommand("SPDeleteEmployee @EmpID", new SqlParameter("@EmpID", 1024));
            //Console.WriteLine($"Records get delete : {data}");
            //Console.ReadLine();



        }
    }
}
