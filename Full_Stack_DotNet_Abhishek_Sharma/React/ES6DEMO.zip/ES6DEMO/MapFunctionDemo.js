//Example 1
const numbers = [1, 2, 3, 4, 5];
const Squares = numbers.map((value) => value * value);
console.log(Squares);
//Example 2
const people = [
  { id: 1, name: "Anurag", BU: "ADM" },
  { id: 2, name: "Jordan", BU: "ADM" },
  { id: 3, name: "Sukesh", BU: "ADM" },
  { id: 4, name: "Abhee", BU: "ADM" },
  { id: 5, name: "Ravi", BU: "ADM" },
];

const ids = people.map(person =>person.id);
console.log(ids);

const divs = people.map(p=>`<div>${p.name}</div>`);
console.log(divs);