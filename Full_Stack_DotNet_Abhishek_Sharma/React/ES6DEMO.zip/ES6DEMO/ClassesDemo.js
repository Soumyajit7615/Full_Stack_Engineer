class Rectangle {
  constructor(height, width) {
    (this.height = height),
    (this.width = width)
  }
  area(){
      console.log(`The area of the rectangle is ${this.height*this.width}`);

  }
}

class Square extends Rectangle{
    constructor(side)
    {
        super(side,side)
    }
}

const rectangle1 = new  Rectangle(7,2);
const rectangle2 = new  Rectangle(14,5);
//console.log(rectangle1.height);
//console.log(rectangle1.width);
rectangle1.area();
//Overriding  method
rectangle2.area = function(){console.log('new implementation')}
rectangle2.area();
const Square1 = new Square(5);
Square1.area();

