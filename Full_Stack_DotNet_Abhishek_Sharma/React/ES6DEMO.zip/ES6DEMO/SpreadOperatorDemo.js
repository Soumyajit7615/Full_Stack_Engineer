//Example 1
const sum = (a, b) => a + b;
const numbers = [2, 3];
console.log(sum(numbers[0], numbers[1]));

console.log(sum(numbers)); //2,3undefined
console.log(sum(...numbers));

//Array
//Example2:
const moreNumbers = [1, ...numbers]; // [ 1, 2, 3 ]
const moreNumbers2 = [1, numbers]; //[ 1, [ 2, 3 ] ]

const moreNumbers3 = [1, ...numbers, 4, 5]; //[ 1, 2, 3, 4, 5 ]
console.log(moreNumbers3);

//Example3:
const otherNumbers = [4, 5];
const concatenatedArrays = [...numbers, ...otherNumbers]; //[ 2, 3, 4, 5 ]
console.log(concatenatedArrays);

//Example 4:

const [first, ...theRemainingValues] = concatenatedArrays;
console.log(first); //2
console.log(theRemainingValues); //[ 3, 4, 5 ]
//Clone the Array
//Example 5
const concatenatedArraysCloned = [...concatenatedArrays];
console.log(concatenatedArraysCloned); //[ 2, 3, 4, 5 ]
//SPREAD OPERATOR - OBJECTS
//Example 6
const person = {
  firstName: "Abhishek",
  lastName: "Sharma",
};

// const person2 = {
//   name: person.firstName,
//   age: 999,
// };

// console.log(person2.name);

//Same thing in more effective way


const person2 ={
...person,
age:999
}
console.log(person2);
//JSON.stringify ,JSON.parse

//Cloning of the object
//Example 7
const person3 = person2; // Shallow Copy
person3.name= 'Manish Sharma' ;

console.log(person2);
console.log(person3);

const  person4 = {...person2}; // Deep copy
person4.name ='Abhijeet';

console.log(person2);
console.log(person4);

// Cloning of object with DE Structuring
//Example 8
const {age,...person5}=person4;
console.log(age);
console.log(person5);



