let person = {
  firstName: "Abhishek",
  lastName: "Sharma",
  age: 999,
  currentDate: new Date(),
};

//instead of doing this
// const firstName = person.firstName;
// const lastName = person.lastName;
// const age = person.age;
// console.log(firstName);

const { firstName, lastName, age } = person;
console.log(firstName);

getAddress = () => {
  return {
    street: "Street 1",
    country: "country 1",
    state: "state1",
  };
};

const {street,country}=getAddress();
console.log(street);

printName = (person)=>{
    console.log(person.firstName);
}

printName2 = ({firstName})=>{
    console.log({firstName});
}
printName2(person);

//De structuring the Array
const arr = [1,2,3,4];
const [first,second,,fourth]= arr;
console.log(second);




