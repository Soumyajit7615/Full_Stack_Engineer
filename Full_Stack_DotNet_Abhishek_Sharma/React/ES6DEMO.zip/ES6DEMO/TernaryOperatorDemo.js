const age = 17;
let message;

if (age >= 18) {
  message = "You shall pass";
} else {
  message = "You shall not pass";
}
console.log(message);
//age=18;//Assignment to constant variable.
message = age >= 18 ? "You shall pass" : "You shall not pass";
console.log(message);

//ENHANCED OBJECT LITERALS
let firstName = "Abhishek";
firstName = "Manish";
let myage = 999;
let date = new Date();

let person = {
  country: "India",
  firstName,
  myage,
  date: new Date(),
};

console.log(person.myage);

let person2 = {
  country: "India",
  firstName,
  date: new Date(),
  myage,
  normalfunction: () => {
    //....
  },
  arrowfunction: () => {
    //...
  },
};

console.log(person2.myage);
person2.normalfunction();
person2.arrowfunction();
