let duplicate = function (value) {
  return value * 2;
};
console.log(duplicate(25));

let duplicate_arrow = (value) => value * 2;

console.log(duplicate_arrow(25));

let duplicate_arrow2 = (value) => value * 2;
console.log(duplicate_arrow2(34));
let duplicate_arrow3 = (value) => {
  return value * 2;
};
console.log(duplicate_arrow3(56));
let printsomething = () => console.log("something");
printsomething();

let addition = (value1, value2) => value1 + value2;
console.log(addition(56, 45));

let complexfunction = () => {
  //this
  //line
  //line2
};

const obj = {
  traditionalFunction: function () {
    console.log("traditional function", this);
  },
  arrowFunction: () => {
    console.log("arrow function", this);
  },
  lastName: "Sharma",
};
console.log('this enviroment',this)
obj.traditionalFunction()
obj.arrowFunction();
