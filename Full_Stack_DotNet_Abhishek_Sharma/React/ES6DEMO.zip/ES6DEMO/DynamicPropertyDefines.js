let propertyName = "Country";
let propertyValue = "India";

let person = {
  [propertyName]: propertyValue,
  lastName:'sharma',
  age :999,
  date: new Date(),
  normalfunction: () => {
    console.log("I am normal function ");
  },
  arrowfunction: () => {
    console.log("I am arrow function ");
  },
};
console.log(person.age);
person.normalfunction();
person.arrowfunction();
console.log(person[propertyName]);

returnValueFromPerson = (prop) => person[prop];
console.log(returnValueFromPerson('lastName'));