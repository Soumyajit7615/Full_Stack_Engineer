console.log("Hello World!!!");
for(var x=1;x<=10;x++)
{
console.log(x);
}