const myname = 'Abhishek Sharma'; //Single quotes
const country = "India";
const greeting = "Hello , "+myname + " , how are you ?";
const greeting2 = `Hello , ${myname} , how are you ?`;//backticks

console.log(greeting2);
const add = (a,b)=>a+b;
const message =`Hello ,${myname}
This is a message for you.
The sum of 2  and 2 is ${add(2,2)}
bye bye`;
console.log(message);
