//var is global access
for(var x=1;x<=10;x++){}
console.log(x);
//let is local access
for(let a=1;a<=10;a++){
console.log(a);
}

let firstName = "Abhishek";
const lastName = "Sharma";
//lastName = "verma";//Assignment to constant variable.

console.log(lastName);
let age = 999;
let birthDay = new Date();
let person = {
  firstName: "soumyajit",
  lastName: "Das",
};

const person2 = {
    firstName: "Harish",
    lastName: "Babu",
  };
person.firstName = 'Manish';
person2.firstName = 'Abhijeet';

console.log(person2.firstName);