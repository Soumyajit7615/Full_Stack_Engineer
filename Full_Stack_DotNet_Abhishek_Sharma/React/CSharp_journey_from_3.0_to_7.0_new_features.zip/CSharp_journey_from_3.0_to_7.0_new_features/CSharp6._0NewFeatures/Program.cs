﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console; //Static imports
using static System.Math; //Static imports

namespace CSharp6._0NewFeatures
{
    //String interpolation
    //Auto-property initializers
    //Static imports
    //Dictionary Initializer
    //Null propagator
    //nameof operator
    //Exception filters
    //Expression bodied members
    class ClsEmployee
    {
        // Auto Implememted Property
        public int EMPID { get; set; } = 1001;// 6.0 way Auto-property initializers
        public string EMPNAME { get; set; } = "ARON";// 6.0 way Auto-property initializers
        public string EMPDESG { get; set; } = "PROGRAMMER";// 6.0 way Auto-property initializers
        public string EMPDEPT { get; set; } = "DEVELOPMENT";// 6.0 way Auto-property initializers
        public ClsEmployee(int EMPID, string EMPNAME, string EMPDESG, string EMPDEPT)
        {
            this.EMPID = EMPID;
            this.EMPNAME = EMPNAME;
            this.EMPDESG = EMPDESG;
            this.EMPDEPT = EMPDEPT;

        }

        //C# 5.0
        public ClsEmployee()
        {

            //this.EMPID = 1001;
            //this.EMPNAME = "Melvin Porter";
            //this.EMPDESG = "HR";
            //this.EMPDEPT = "ADM";

        }



    }
    public class Person
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public List<Person> Childern { get; set; }

    }

    class Program
    {
        static void Main(string[] args)
        {

            #region String interpolation
            int EmpId = 10001;
            string Name = "Sukesh";
            float Salary = 1234.567f;


            Console.WriteLine("The Employee ID : {0} and Employee Name :{1}", EmpId, Name);
            Console.WriteLine("The Employee ID : " + EmpId + " Employee Name : " + Name);
            Console.WriteLine("The EmpID : {0:f} and Employee salary : {1:f} ", EmpId, Salary);

            string name = "Mark";
            var date = DateTime.Now;

            // Composite formatting:
            Console.WriteLine("Hello, {0}! Today is {1}, it's {2:HH:mm} now.", name, date.DayOfWeek, date);
         
            // String interpolation:
            Console.WriteLine($"Hello, {name}! Today is {date.DayOfWeek}, it's {date:HH:mm} now.");
            // Both calls produce the same output that is similar to:
            // Hello, Mark! Today is Wednesday, it's 19:40 now.

            #endregion
            #region Auto-property initializers
            //C# 5.0 WAY
            ClsEmployee clsEmployee = new ClsEmployee()
            {
                EMPID = 1001,
                EMPNAME = "Melvin Porter",
                EMPDESG = "HR",
                EMPDEPT = "ADM",

            };
            //Getting output after 6.0 way Auto-property initializers
            ClsEmployee Emp60Way = new ClsEmployee();
            Console.WriteLine(Emp60Way.EMPID + " " + Emp60Way.EMPNAME + " " + Emp60Way.EMPDESG + " " + Emp60Way.EMPDEPT);

            #endregion
            #region  Static imports or using static directive

            Console.WriteLine("This message display by normally console writeline:");
            WriteLine("This messsage got displayed after static  import of system.console class ");

            double sqrval = Math.Sqrt(16);
            WriteLine($"The square root of 16 : {sqrval}");
            decimal roundNumber = Round(1234.65678m);
            Console.WriteLine($"After round the result : {roundNumber}");
            #endregion
            #region Dictionary Initializer
            //CSharp 5.0 WAY
            Dictionary<string, string> PackageManagers = new Dictionary<string, string>();
            PackageManagers.Add("Nuget.org", "DOTNET");
            PackageManagers.Add("MAVEN", "Java");
            PackageManagers.Add("Nodejs", "JAVASCRIPT");

            //CSharp 6.0 WAY
            Dictionary<string, string> ExecutiveFile = new Dictionary<string, string>()
            {
                ["winword.exe"] = "MS WORD",
                ["powerpnt.exe"] = "Power Point",
                ["Control.exe"] = "Control Panel"

            };
            foreach (KeyValuePair<string, string> exe in ExecutiveFile)
            {
                Console.WriteLine($"EXEC NAME : {exe.Key}  APPLICATION NAME : {exe.Value}");

            }

            #endregion

            //Person person = new Person();
            //person.ID = 12345;
            //person.Name = "Sukesh";
            //person.Childern = new List<Person>()
            //{
            //    new Person(){ID = 1001,Name="Sukesh Junior",Childern=null},
            //    new Person(){ID = 1002,Name="Sukesh Elder",Childern=null},

            //};
            #region NULLABLE TYPE REVISED
            int myint = 123;

            Console.WriteLine("The value : {0} and type : {1}", myint, myint.GetType());
            int? myonemoreint = 12345;


            int myresult = myonemoreint ?? -1;
            string PersonName = null;
            string DefaultName = PersonName ?? "NA";
            Console.WriteLine($"The Name of the person : {DefaultName}");
            Console.WriteLine("The value : {0} and type : {1}", myresult, myresult.GetType());

            #endregion
            #region Null propagator
            //Traditional way of handling Null
            Person person = new Person()
            { Name = "Aaron Hawkins" };
            Console.WriteLine("First Child");
            if (person.Childern != null)
            {
                if (person.Childern.FirstOrDefault() != null)
                {
                    Console.WriteLine(person.Childern.First().Name);
                }
                else
                    Console.WriteLine("NA");
            }
            else
            {
                Console.WriteLine("NA");

            }
            Console.WriteLine("By Using C# 6.0 Way:");
            Person person1 = new Person()
            { Name = "Melvin Porter" };
            Console.WriteLine("First Child:");
            Console.WriteLine(person1.Childern?.FirstOrDefault()?.Name ?? "NA");

            #endregion
            #region nameof operator
            Console.WriteLine(nameof(System.Collections.Generic));  // output: Generic
            Console.WriteLine(nameof(List<int>));  // output: List
            Console.WriteLine(nameof(List<int>.Count));  // output: Count
            Console.WriteLine(nameof(List<int>.Add));  // output: Add
            var numbers = new List<int> { 1, 2, 3 };
            Console.WriteLine(nameof(numbers));  // output: numbers
            Console.WriteLine(nameof(numbers.Count));  // output: Count
            Console.WriteLine(nameof(numbers.Add));  // output: Add
            var mypath = @"c:\Hello";
            var @new = 5;
            Console.WriteLine(nameof(@new));  // output: new

            #endregion
            #region Exception filters
            int r = 0, num1 = 0, num2 = 0;
            try
            {
                if (num2 == 0)
                {
                    //r = num1 / num2;
                    throw new DivideByZeroException("Num2isZero");
                }

                Console.WriteLine($"Result : {r}");


            }

            catch (DivideByZeroException ex) when (ex.Message.Contains("Num2isZero"))
            {
                WriteLine("Error Message  Num2isZero : " + ex.Message);
            }
            catch (DivideByZeroException ex) when (ex.Message.Contains("ErrorType2"))
            {
                WriteLine("Error Message : " + ex.Message);
            }

        }
        #endregion
    }
}

