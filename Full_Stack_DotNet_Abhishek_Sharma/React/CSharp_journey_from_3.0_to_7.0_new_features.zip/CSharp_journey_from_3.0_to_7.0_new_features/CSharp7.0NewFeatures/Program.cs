﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp7._0NewFeatures
{
    //Local functions
    //Ref locals and returns
    //Tuples and deconstruction
    //Out variables
    //Pattern matching
    //Expanded expression bodied members
    class CustomerDetails
    {
        private int CustomerCode = 1001;
        private string CustomerName = "Adria Russell";
        private string CustomerAddress = "Miami Beach North Dakota 58563";
        private string CustomerContact = "(516) 745-4496";
        private DateTime AccountActiveDate = new DateTime(2020, 12, 29);

        public void GetCustomerDetails(out int CustomerCode, out string CustomerName, out string CustomerAddress, out string CustomerContact, out DateTime AccountActiveDate)
        {
            CustomerCode = this.CustomerCode;
            CustomerName = this.CustomerName;
            CustomerAddress = this.CustomerAddress;
            CustomerContact = this.CustomerContact;
            AccountActiveDate = this.AccountActiveDate;
        }


    }
    class ClsEmployee
    {
        int EMPID;
        string NAME;
        string DESG;
        string DEPT;
        public ClsEmployee(int EMPID, string NAME, string DESG, string DEPT)
        {
            this.EMPID = EMPID;
            this.NAME = NAME;
            this.DESG = DESG;
            this.DEPT = DEPT;
        }
        public void Deconstruct(out int EMPID, out string NAME, out string DESG)
        {
            EMPID = this.EMPID;
            NAME = this.NAME;
            DESG = this.DESG;

        }
        public void Deconstruct(out int EMPID, out string NAME, out string DESG, out string DEPT)
        {
            EMPID = this.EMPID;
            NAME = this.NAME;
            DESG = this.DESG;
            DEPT = this.DEPT;
        }
    }
    class MyOldNormalClass
    {
        //Normal Property
        public int MyProperty { get; set; }
        //Read Only Property
        public int ReadOnlyMyProperty { get; }

        //This string Array
        private string[] Gamestypes = { "Baseball", "Basketball", "Football",
                              "Hockey", "Soccer", "Tennis",
                              "Volleyball" };
        //Indexer
        public string this[int index]
        {
            get
            {
                if (index >= 0 && index < Gamestypes.Length)
                {
                    return Gamestypes[index];
                }
                else
                    throw new IndexOutOfRangeException();
            }
            set
            {
                if (index >= 0 && index < Gamestypes.Length)
                {
                    Gamestypes[index] = value;
                }
                else
                    throw new IndexOutOfRangeException();

            }
        }

        //Constructor
        public MyOldNormalClass()
        {
            Console.WriteLine("I am the Constructor MyNormalClass");
        }
        //Finalizer
        ~MyOldNormalClass()
        {
            Console.WriteLine("I am the Finalizer / Destructor ");
        }
        //Method
        public void WithOutExpressionbodiedMethod()
        {

            Console.WriteLine("I am the Method of MyOldNormalClass");
        }
    }
    class ExpressionBodiedMembersDemo
    {
        public ExpressionBodiedMembersDemo()
        {
        }
        //Normal Property
        public int MyProperty { get => myProperty; set => myProperty = value; }
        //Read Only Property
        public int ReadOnlyMyProperty => readOnlyMyProperty;
        //This string Array
        private string[] Gamestypes = { "Baseball", "Basketball", "Football",
                              "Hockey", "Soccer", "Tennis",
                              "Volleyball" };
        private int myProperty;
        private readonly int readOnlyMyProperty;

        public string this[int index]
        {
            get
            {
                if (index >= 0 && index < Gamestypes.Length)
                {
                    return Gamestypes[index];
                }
                else
                    throw new IndexOutOfRangeException();
            }
            set
            {
                if (index >= 0 && index < Gamestypes.Length)
                {
                    Gamestypes[index] = value;
                }
                else
                    throw new IndexOutOfRangeException();

            }
        }
        public void WithOutExpressionbodiedMethod() => Console.WriteLine("I am the Method of MyOldNormalClass");

        
    }

    class Program
    {
        //CSharp 6.0 Way
        public static Tuple<int, int> Addition(int a, int b)
        {
            int c = a + b;
            int d = a * b;
            Tuple<int, int> t = Tuple.Create(c, d);
            return t;


        }

        //CSharp 7.0 Way
        public static (int, int) Add(int a, int b)
        {
            int c = a + b;
            int d = a * b;
            return (c, d);


        }
        public static (int Sum, int Product) AddII(int a, int b)
        {
            int c = a + b;
            int d = a * b;
            return (c, d);


        }
        public static ref string GetSubscriber(string[] users, int index)
        {
            return ref users[index];
        }
        static void Main(string[] args)
        {
            #region Local functions
            Console.WriteLine("C# 3.0 ");
            Func<float, int, float> AreaOfCircle = (r, x) => (r * x);

            Console.WriteLine($"Area Of Circle : {AreaOfCircle(3.14f, 25)}");

            var add = new Func<int, int, int>((num1, num2) => num1 + num2);
            var result = add(10, 20);
            Console.WriteLine($"Addition of both the numbers : {result}");
            int Adition(int num1, int num2)
            {
                return num1 + num2;
            }
            int StringLength(string str)
            {
                return str.Length;
            }
            Console.WriteLine(Adition(34, 45));
            Console.WriteLine($"The length of my name : {StringLength("Abhishek")}");
            #endregion
            #region Ref locals and returns
            //Ref locals
            string[] Subscribers = { "BLAZE", "CLARE", "SANDRINE", "ADNRES", "MADDEN", "ADELYN" };

            ref string Subscriber = ref Subscribers[3];
            Console.WriteLine(string.Join(" ", Subscribers));
            Console.WriteLine(Subscriber);
            Subscriber = "JULIUS";
            Console.WriteLine(Subscriber);
            Console.WriteLine(string.Join(" ", Subscribers));
            Subscribers = null;
            Console.WriteLine(Subscriber);
            //Console.WriteLine(string.Join(" ", Subscribers));
            //Note : When the value of array changes , then impact on the ref variable . And array will destroy
            // then , nothing impact on  reference variable. Make sure , array can have , it will not work for collection 


            //Ref returns
            string[] Subscribers2 = { "BLAZE", "CLARE", "SANDRINE", "ADNRES", "MADDEN", "ADELYN" };
            ref string Subscrib = ref GetSubscriber(Subscribers2, 5);
            Console.WriteLine(Subscrib);
            Console.WriteLine(string.Join(" ", Subscribers2));
            Subscrib = "TUCKER";
            Console.WriteLine(Subscrib);
            Console.WriteLine(string.Join(" ", Subscribers2));
            #endregion
            #region Tuples 
            Console.WriteLine("CSharp 6.0 WAY :");
            Tuple<int, int> obj = Addition(123, 45);

            Console.WriteLine("Sum of two numbers:" + obj.Item1);
            Console.WriteLine("Product of two numbers:" + obj.Item2);

            Console.WriteLine("CSharp 7.0 way:");
            var td = Add(234, 456);
            Console.WriteLine("Sum of two numbers:" + td.Item1);
            Console.WriteLine("Product of two numbers:" + td.Item2);
            //More improvement 
            var (Sum, Product) = Add(234, 456);
            Console.WriteLine("Sum of two numbers:" + Sum);
            Console.WriteLine("Product of two numbers:" + Product);
            var objII = AddII(234, 456);
            Console.WriteLine("Sum of two numbers:" + objII.Sum);
            Console.WriteLine("Product of two numbers:" + objII.Product);
            var (SumII, ProductII) = AddII(234, 456);
            Console.WriteLine("Sum of two numbers:" + SumII);
            Console.WriteLine("Product of two numbers:" + ProductII);

            #endregion
            #region Deconstruction

            ClsEmployee Emp = new ClsEmployee(1001, "Aaron", "PAT", "FIN");

            (int EMPID, string NAME, string DESG, string DEPT) = Emp;
            Console.WriteLine("EMP ID : {0}", EMPID);
            Console.WriteLine("EMP NAME : {0}", NAME);
            Console.WriteLine("EMP DESG : {0}", DESG);
            Console.WriteLine("EMP DEPT : {0}", DEPT);

            (int EMPIDII, string NAMEII, _) = Emp;
            Console.WriteLine("EMP ID : {0}", EMPIDII);
            Console.WriteLine("EMP NAME : {0}", NAMEII);

            #endregion
            #region Out variables
            //CustomerDetails customerDetails = new CustomerDetails();
            //int CustomerCode; string CustomerName; string CustomerAddress; string CustomerContact;
            //DateTime ActiveDate;
            //DateTime.TryParse("29/12/2020", out ActiveDate);

            //customerDetails.GetCustomerDetails(out CustomerCode, out CustomerName, out CustomerAddress, out CustomerContact, out ActiveDate);
            //Console.WriteLine("Customer Details are as follows :");
            //Console.WriteLine($"Customer Code : {CustomerCode} \nCustomer Name : {CustomerName}\nCustomer Address : {CustomerAddress}  \nCustomer Contact : {CustomerContact} \nActive Date : {ActiveDate}");



            //C# 7.0 way

            //int CustomerCode; string CustomerName; string CustomerAddress; string CustomerContact;
            //DateTime ActiveDate;
            //DateTime.TryParse("29/12/2020", out ActiveDate);
            CustomerDetails customerDetails2 = new CustomerDetails();
            customerDetails2.GetCustomerDetails(out int CustomerCode, out string CustomerName, out string CustomerAddress, out string CustomerContact, out DateTime ActiveDate);
            Console.WriteLine("Customer Details are as follows :");
            Console.WriteLine($"Customer Code : {CustomerCode} \nCustomer Name : {CustomerName}\nCustomer Address : {CustomerAddress}  \nCustomer Contact : {CustomerContact} \nActive Date : {ActiveDate}");



            #endregion

            string message = "Hello";


        }
    }
}
