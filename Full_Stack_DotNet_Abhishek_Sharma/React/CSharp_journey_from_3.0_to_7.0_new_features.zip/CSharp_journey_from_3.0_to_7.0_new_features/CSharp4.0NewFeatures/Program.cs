﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp4._0NewFeatures
{
    //DYNAMIC
    //NAMED AND OPTIONAL PARAMETER
    //COVARIANCE AND CONTRAVARIANCE
    //OFFICE COM INTEROP 
    //TaskParallelLibraryTPL
    class Program
    {
        public void ShowDetails(int ProjectCode = 1234, int EmpCode = 1001, string EmpName = "Jordan", string EmpDept = "PTA")
        {

            Console.WriteLine(ProjectCode + " " + EmpCode + " " + EmpName + " " + EmpDept);

        }
        static void Main(string[] args)
        {
            #region Dynamic
            var myint = 10;
            Console.WriteLine(myint + " " + myint.GetType());
            //myint = "Dhiraj"; //error
            dynamic dyna = 10;
            Console.WriteLine(dyna + " " + dyna.GetType());
            dyna = "Sukesh";
            Console.WriteLine(dyna + " " + dyna.GetType());
            dyna = 1234.56m;
            Console.WriteLine(dyna + " " + dyna.GetType());
            dyna = DateTime.Now;
            Console.WriteLine(dyna + " " + dyna.GetType());
            dyna = 1234.56f;
            Console.WriteLine(dyna + " " + dyna.GetType());
            #endregion
            #region Named And Optional Parameter
            Program pp = new Program();
            pp.ShowDetails();//OPTIONAL PARAMETER
            pp.ShowDetails(EmpName: "Sukesh", EmpCode:1002);//NAMED PARAMETER
            #endregion
            #region Covariance And Contravariance
            // See class file CovarianceAndContravarianceDemo
            #endregion

        }
    }
}
