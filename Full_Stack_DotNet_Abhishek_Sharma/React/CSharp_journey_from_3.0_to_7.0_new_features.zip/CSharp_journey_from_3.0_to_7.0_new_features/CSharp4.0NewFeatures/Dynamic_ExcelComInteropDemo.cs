﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel; // API
namespace CSharp4._0NewFeatures
{
    class Dynamic_ExcelComInteropDemo
    {
        static void Main(string[] args)
        {
            var excel = new Excel.Application();
            var workbook = excel.Workbooks.Add();
            var sheet = excel.ActiveSheet;
            excel.Visible = true;
            excel.Cells[1, 1] = "Hi i am from C#";
            excel.Columns[1].AutoFit();
            excel.Cells[2, 1] = 10;
            excel.Cells[3, 1] = 15;
            excel.Cells[4, 1] = 16;
            excel.Cells[5, 1] = 20;
            excel.Cells[6, 1] = 3;
            excel.Cells[7, 1] = 11;
            excel.Cells[2, 2] = 13;
            excel.Cells[3, 2] = 14;
            excel.Cells[4, 2] = 21;
            excel.Cells[5, 2] = 30;
            excel.Cells[6, 2] = 33;
            excel.Cells[7, 2] = 12;
            var chart = workbook.Charts.Add(After: sheet);
            chart.ChartWizard(Source: sheet.Range("A2", "B7"));

        }
    }
}
