﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CSharp4._0NewFeatures
{
    class TaskParallelLibraryTPLDemo
    {
        static void Main(string[] args)
        {
            //Thread P1 = new Thread(RunMillionIterations);
            //P1.Start();
            Parallel.For(0, 1000000, x => RunMillionIterations());
            Console.Read();
        }
        private static void RunMillionIterations()
        {
            string x = "";
            for (int iIndex = 0; iIndex < 1000000; iIndex++)
            {
                x = x + "s";
                Console.WriteLine(x);
            }



        }
    }
}
