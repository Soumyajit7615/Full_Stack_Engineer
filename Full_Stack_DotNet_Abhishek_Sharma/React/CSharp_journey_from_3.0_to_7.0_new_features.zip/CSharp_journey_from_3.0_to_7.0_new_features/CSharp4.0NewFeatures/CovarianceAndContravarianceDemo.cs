﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp4._0NewFeatures
{
    class Person
    {
        public string Name { get; set; }
    }
    class Employee : Person  {  }
    class Manager : Person { }
    class CovarianceAndContravarianceDemo
    {
        delegate void MyFunctionPointer<in T>(T obj);
        static void Main(string[] args)
        {
            Person perObj = new Employee();//Convariance
            perObj = new Manager();//Convariance
            IEnumerable<Person> PerList = new List<Employee>();//Covariance

            float valfloat = 123.45f;
            int valInt = (int)valfloat;

            

            MyFunctionPointer<Person> DelPer = MyFunction;
            MyFunctionPointer<Employee> DelEmp = DelPer;//Parent----> Child
            //Contravariance



        }
        static void MyFunction(Person obj)
        {
            Console.WriteLine("Name : {0}", obj.Name);
        }
    }
}
