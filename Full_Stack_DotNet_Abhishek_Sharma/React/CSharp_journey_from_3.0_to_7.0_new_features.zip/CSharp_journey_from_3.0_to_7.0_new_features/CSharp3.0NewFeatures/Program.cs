﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;

namespace CSharp3._0NewFeatures
{
    //Auto Implemented Properties
    //Object Initializer
    //Collection Intializer
    //Local Variable Type Inference var
    //Anonymous Type
    //Extension Method 
    //Lambda Expression
    //Query Expression
    //Partial Method
    //Expression Trees
    struct StrEmployee
    {
        int Code;
        string Name;
    }
    partial class MyPartialClass
    {
        partial void OnSomethingHappened(string s);//Partial Method
    }

    // This part can be in a separate file.
    partial class MyPartialClass
    {
        //Comment out this method and the program
        //Will still compile.
        //NOTE : No access modifiers are allowed. Partial methods are implicitly private.
        partial void OnSomethingHappened(String s)//Partial Method
        {
            Console.WriteLine("Something happened: {0}", s);
        }
        public void CallPartialMethod()
        {
            OnSomethingHappened("Hello Partial");
        }

    }
    public static class JustExtension
    {
        public static int WordCount(this string s)
        {

            return s.Split(new char[] { ' ', '\t', '.' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }
        public static void Method2(this Program p)
        {
            Console.WriteLine("I am Extension method of Program class:");
            Console.WriteLine(" ", p.ProgramCode);
        }
    }
    public delegate int AddDelReturn(int x, int y);
    public delegate void AddDelNonReturn(int x, int y);
    public class Program
    {
        public int ProgramCode { get; set; }
        public void Method1()//Instance Method
        {
            Console.WriteLine("I am method1 from program class");
        }

        static void Main(string[] args)
        {
            #region Auto Implemented Properties
            #endregion
            #region Object Initializer

            ClsEmployee obj = new ClsEmployee()
            {
                EmpID = 1001,
                EmpDept = "Training",
                EmpName = "Abhishek"
            };
            #endregion
            #region Collection Intializer


            List<ClsEmployee> EmpList = new List<ClsEmployee>()
            {

            new ClsEmployee() { EmpID = 1001, EmpName = "Sukesh", EmpDept = "PAT" },
            new ClsEmployee() { EmpID = 1002, EmpName = "Anurag", EmpDept = "PAT" },
            new ClsEmployee() { EmpID = 1003, EmpName = "Jordan", EmpDept = "PAT" }
            };
            Console.WriteLine("Employee details are as follows:");
            foreach (ClsEmployee Emp in EmpList)
            {
                Console.WriteLine("EMPID : {0}", Emp.EmpID);
                Console.WriteLine("EmpName : {0}", Emp.EmpName);
                Console.WriteLine("EmpDept : {0}", Emp.EmpDept);
                Console.WriteLine();
            }
            #endregion
            #region Local Variable Type Inference var
            var intvar = 10;
            Console.WriteLine(intvar + " " + intvar.GetType());
            var strvar = "Guy Name";
            Console.WriteLine(strvar + " " + strvar.GetType());
            #endregion
            #region Anonymous Type
            ClsEmployee Empp = new ClsEmployee()
            {
                EmpID = 1002,
                EmpName = "Vidhi",
                EmpDept = "HR"

            };
            var Employee = new { EmpID = 1234, EmpName = "Dheeraj", EmpDept = "PAT" };
            Console.WriteLine(Employee.EmpID + " " + Employee.EmpName + " " + Employee.EmpDept);
            Console.WriteLine(Employee.GetType());
            #endregion
            #region Extension Method
            string str = "This is           just string   Demo";
            Console.WriteLine("Lenght of string : {0}", str.Length);
            Console.WriteLine("Lenght of string : {0}", str.Count());
            Console.WriteLine("Word count : {0}", str.WordCount());
            Program pp = new Program();
            pp.Method1();
            pp.Method2();
            #endregion
            #region Lambda Expression
            AddDelReturn delAdd = (a, b) => (a + b);//single line code
            AddDelNonReturn delAddII = (a, b) =>
            {
                Console.WriteLine("Addition of Numbers : {0}", a + b);
                Console.WriteLine("Substractio of Numbers : {0}", a - b);
                Console.WriteLine("Multiplication : {0}", a * b);
                Console.WriteLine("Division : {0}", a / b);

            };

            AddDelNonReturn DelDel = (a, b) => Console.WriteLine(a + b);
            int result = delAdd(25, 26);
            Console.WriteLine(result);
            delAddII(456, 654);
            #endregion
            #region Query Expression
            string[] Names = { "Shubham", "Nehataj", "Swathi", "Mounika", "Mayank" };
            foreach (string nm in Names)
            {
                if (nm.Contains('S') == true)
                {
                    Console.WriteLine(nm);

                }
            }
            // => goes into
            Console.WriteLine("\n");
            var selected = Names.Where(n => n.Contains('S'));
            IEnumerable<string> IEn = Names.Where(n => n.Contains('S'));
            //IQueryable : When data will come from database
            //IEnumerable: When data will come from collection
            Console.WriteLine("By Using IEnumerable ");
            foreach (string item in IEn)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine(selected.GetType());
            foreach (string nn in selected)
            {
                Console.WriteLine(nn);
            }
            #endregion
            #region Partial Method
            MyPartialClass myPartialClass = new MyPartialClass();
            myPartialClass.CallPartialMethod();

            #endregion
            #region Expression Trees
            //Create the expression parameters
            ParameterExpression num1 = Expression.Parameter(typeof(int), "num1");
            ParameterExpression num2 = Expression.Parameter(typeof(int), "num2");

            //Create the expression parameters
            ParameterExpression[] parameters = new ParameterExpression[] { num1, num2 };

            //Create the expression body
            BinaryExpression body = Expression.Add(num1, num2);

            //Create the expression 
            Expression<Func<int, int, int>> expression = Expression.Lambda<Func<int, int, int>>(body, parameters);

            // Compile the expression
            Func<int, int, int> compiledExpression = expression.Compile();

            // Execute the expression. 
            int rest = compiledExpression(3, 4); //return 7
            Console.WriteLine(rest);
            #endregion

        }

        void ShowData(StrEmployee strEmployee)
        {

        }
    }
}
