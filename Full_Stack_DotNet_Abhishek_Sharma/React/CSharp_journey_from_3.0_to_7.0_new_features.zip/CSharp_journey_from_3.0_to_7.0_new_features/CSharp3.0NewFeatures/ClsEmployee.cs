﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp3._0NewFeatures
{
    class ClsEmployee
    {
        public ClsEmployee()
        {

        }
        public ClsEmployee(int EmpID, string EmpName, string EmpDept)
        {

        }
        //Auto Implemented Properties
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public string EmpDept { get; set; }

        //private string _DeptLocation;

        //public string DeptLocation
        //{
        //    get { return _DeptLocation; }
        //    set { _DeptLocation = value; }
        //}
       



    }
}
