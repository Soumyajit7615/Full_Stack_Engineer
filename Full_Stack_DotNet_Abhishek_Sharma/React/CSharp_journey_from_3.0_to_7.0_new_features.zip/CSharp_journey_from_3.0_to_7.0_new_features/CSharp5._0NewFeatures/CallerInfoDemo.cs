﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

namespace CSharp5._0NewFeatures
{
    class CallerInfoDemo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main method started :");
            MyMethodB();
            MyMethodA();
            Console.WriteLine("Main method end :");


        }

        static void MyMethodA()
        {
            MyMethodB();

        }
        static void MyMethodB([CallerMemberName] string membername = "", [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0)
        {
            Console.WriteLine("{0} called MyMethodB , sourceFilePath :{1} sourceLineNumber:{2}", membername, sourceFilePath, sourceLineNumber);

        }

    }
}
