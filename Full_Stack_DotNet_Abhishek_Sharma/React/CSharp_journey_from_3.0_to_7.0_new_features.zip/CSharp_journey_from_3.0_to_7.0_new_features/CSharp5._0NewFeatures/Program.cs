﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CSharp5._0NewFeatures
{
    //ASYC AND WAIT 
    //Caller info attributes
    class Program
    {
        static void Main(string[] args)
        {
            #region ASYC AND WAIT
            //ASYC AND WAIT : They are markers which mark code positions from where control should resume 
            //                after a task (thread) completes

            Console.WriteLine("Main Thread started:");
            Method();
            Console.WriteLine("Main Thread ended:");
            //Console.ReadLine();
            #endregion

            #region Caller info attributes

            #endregion


        }
        public static async void Method()//Asynchronous members
        {
            await Task.Run(new Action(Longtask));
            Console.WriteLine("New thread");// This line of code will wait until long task finishes


        }
        //public static void Method()
        //{
        //    //Task.Run(new Action(Longtask));
        //    Longtask();
        //    Console.WriteLine("New thread");// This line of code will wait until long task finishes


        //}
        public static void Longtask()
        {
            Thread.Sleep(500);
            //string x = "";
            //for (int iIndex = 0; iIndex < 1000000000; iIndex++)
            //{
            //    x = x + "s";
            //    Console.WriteLine(x);
            //}

            Console.WriteLine("Hello");
        }

    }
}
