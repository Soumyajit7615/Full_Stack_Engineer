﻿using System;

namespace CodeAnalysis
{

    interface IEmployee
    {

    }
    interface IEinterface
    {

    }
    struct MyStruct
    {

    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
          


        }
    }
}
