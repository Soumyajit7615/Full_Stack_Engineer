import React from "react";

const Home = () => {
  return (
    <div className="container">
      <div className="py-4">
        <h1>Home Page</h1>
      </div>
    </div>
  );
};

export default Home;
