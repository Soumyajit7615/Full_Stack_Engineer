﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ExperiencePostCoreWebApi.Migrations
{
    public partial class UpdateEmployeeprofilepic : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpID",
                keyValue: 1,
                column: "ProfilePicture",
                value: "NoImage.png");

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpID",
                keyValue: 2,
                column: "ProfilePicture",
                value: "NoImage.png");

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpID",
                keyValue: 3,
                column: "ProfilePicture",
                value: "NoImage.png");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpID",
                keyValue: 1,
                column: "ProfilePicture",
                value: "no-image");

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpID",
                keyValue: 2,
                column: "ProfilePicture",
                value: "no-image");

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpID",
                keyValue: 3,
                column: "ProfilePicture",
                value: "no-image");
        }
    }
}
