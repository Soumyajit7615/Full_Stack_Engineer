﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Diagnostics;

namespace MVCCOREActionFilters.Models
{
    public class CustomAsyncActionFilter : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {

            //To do : before the action executes  
            //Pre processing logic
            Trace.WriteLine("Action " + context.ActionDescriptor.DisplayName + " has Executing at " + DateTime.Now.ToString());

            await next();
            //To do : after the action executes  

            //Post process logic
            Trace.WriteLine("Action" + context.ActionDescriptor.DisplayName + " has Executed at " + DateTime.Now.ToString());
        }
    }
}
