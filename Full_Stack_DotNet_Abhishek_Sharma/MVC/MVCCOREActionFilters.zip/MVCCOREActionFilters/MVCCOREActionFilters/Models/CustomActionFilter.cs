﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;

namespace MVCCOREActionFilters.Models
{
    public class CustomActionFilter : IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
            //Post process logic

            Trace.WriteLine("Action" + context.ActionDescriptor.DisplayName + " has Executed at " + DateTime.Now.ToString());


        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            //Pre processing logic
            Trace.WriteLine("Action " + context.ActionDescriptor.DisplayName + " has Executing at " + DateTime.Now.ToString());
        }

    }
}
