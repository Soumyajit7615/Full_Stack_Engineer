﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCExceptionHandlingDemo.Models;

//What if some actions have different ways of handling exceptions and some //actions want to handle differently.


namespace MVCExceptionHandlingDemo.Controllers
{
    [HandleError]
    //[HandleError(ExceptionType = typeof(DivideByZeroException), View = "DError")]
    //[HandleError(ExceptionType = typeof(NullReferenceException), View = "NRError")]
    
    public class NormalControllerController : Controller
    {
        // GET: NormalController
       
        //[HandleError(ExceptionType =typeof(DivideByZeroException),View ="DError")]
        //[HandleError(ExceptionType = typeof(NullReferenceException), View = "NRError")]

        //[MyCustomExFilter]
        public ActionResult Index()
        {
            ClsEmployee emp = new ClsEmployee();
            emp = null;
            emp.Show(); 

            int i = 0, num = 10;
            i = num / i;
            return View();
        }
        //[HandleError]
        //[MyCustomExFilter]
        public ActionResult Index2()
        {
            int i = 0, num = 10;
            i = num / i;
            return View();
        }
    }
}