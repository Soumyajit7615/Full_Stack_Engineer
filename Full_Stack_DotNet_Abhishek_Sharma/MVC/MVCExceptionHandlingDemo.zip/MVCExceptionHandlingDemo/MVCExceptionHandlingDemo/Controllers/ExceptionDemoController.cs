﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCExceptionHandlingDemo.Controllers
{
    //Reusability using inheritance
    //APPROACH 3://Solution of the problem , how to reuse the logic across
    //multiple controller

    public class BaseController : Controller
    {
        protected override void OnException(ExceptionContext filterContext)
        {
            ViewResult v = new ViewResult();
            v.ViewName = "Error";
            filterContext.Result = v;
            filterContext.ExceptionHandled = true;
        }



    }

     //public class ExceptionDemoController : Controller
    public class ExceptionDemoController : BaseController

    {
        //APPROACH 2//Override OnException of the Controller.
        // GET: ExceptionDemo
        //APPROACH 1//DRY : DO NOT REPEAT YOURSELF
        //protected override void OnException(ExceptionContext filterContext)
        //{
        //    ViewResult v = new ViewResult();
        //    v.ViewName = "Error";
        //    filterContext.Result = v;
        //    filterContext.ExceptionHandled = true;
        //}
        public ActionResult Index()
        {
            //try
            //{
            int i = 0, num = 10;
            i = num / i;
            return View();
            //}
            //catch (Exception e)
            //{

            //    return View("Error");
            //}


        }
        public ActionResult Index2()
        {
            //try
            //{
            int i = 0, num = 10;
            i = num / i;
            return View();
            //}
            //catch (Exception e)
            //{

            //    return View("Error");
            //}


        }
    }
}