﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MVCExceptionHandlingDemo
{
    public class MyCustomExFilter : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            ViewResult v = new ViewResult();
            v.ViewName = "Error2";
            filterContext.Result = v;
            filterContext.ExceptionHandled = true;
            Exception e = filterContext.Exception;
        }

    }
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            //To show the default error message 
            //GlobalFilters.Filters.Add(new HandleErrorAttribute());
            //GlobalFilters.Filters.Add(new MyCustomExFilter());
            HandleErrorAttribute a1 = new HandleErrorAttribute();
            a1.ExceptionType = typeof(DivideByZeroException);
            a1.View = "DError";
            GlobalFilters.Filters.Add(a1);
            HandleErrorAttribute a2 = new HandleErrorAttribute();
            a2.ExceptionType = typeof(NullReferenceException);
            a2.View = "NRError";
            GlobalFilters.Filters.Add(a2);
            GlobalFilters.Filters.Add(new HandleErrorAttribute());

        }
    }
}
