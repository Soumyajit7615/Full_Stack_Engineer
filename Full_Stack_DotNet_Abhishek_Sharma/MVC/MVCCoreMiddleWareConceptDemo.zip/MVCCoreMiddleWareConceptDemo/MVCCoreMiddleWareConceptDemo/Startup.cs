using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCoreMiddleWareConceptDemo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //Home / Middleware inject according to url
            
            app.Map("/Home", Execute);
            //https://localhost:44303/?search=test
            //?search==test
            app.MapWhen(context =>
            {
                return context.Request.Query.ContainsKey("search");
            }, ExecuteSearch);

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
            //MIDDLE WARE LOGIC
            //app.Run(async context =>
            //{
            //    await context.Response.WriteAsync("Hello, World");
            //});

            //By having logic in local function
            //app.Use(async (context, next) => Logic1(context, next));
            //app.Use(async (context, next) => Logic2(context, next));
            //app.Use(async (context, next) => Logic3(context));

            // By having logic from middleware class
            //app.UseMiddleware<MiddlewareLogic1>();
            //app.UseMiddleware<MiddlewareLogic2>();
            //app.UseMiddleware<MiddlewareLogic3>();

            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
        private void Execute(IApplicationBuilder app)
        {
            app.Run(async context => await LogicHome(context));

        }

        private async Task LogicHome(HttpContext context)
        {
            await context.Response.WriteAsync("Logic Home");
        }
        private void ExecuteSearch(IApplicationBuilder app)
        {
            app.Run(async context => await LogicSearch(context));
        }

        private async Task LogicSearch(HttpContext context)
        {
            await context.Response.WriteAsync("Login Serach");

        }
        //TASK CALLED
        public async Task Logic1(HttpContext obj, Func<Task> next)
        {
            await obj.Response.WriteAsync("Logic 1\n");
            await next.Invoke();



        }
        //TASK CALLED
        public async Task Logic2(HttpContext obj, Func<Task> next)
        {
            await obj.Response.WriteAsync("Logic 2\n");
            await next.Invoke();



        }
        //TASK CALLED
        public async Task Logic3(HttpContext obj)
        {
            await obj.Response.WriteAsync("Logic 3\n");



        }
    }
}
