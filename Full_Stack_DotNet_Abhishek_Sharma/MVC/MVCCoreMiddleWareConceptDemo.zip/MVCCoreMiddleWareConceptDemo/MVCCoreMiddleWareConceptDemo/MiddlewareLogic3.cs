﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCoreMiddleWareConceptDemo
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class MiddlewareLogic3
    {
        private readonly RequestDelegate _next;

        public MiddlewareLogic3(RequestDelegate next)
        {
            //_next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            await httpContext.Response.WriteAsync("This is Logic3 \n");
            //await _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class MiddlewareLogic3Extensions
    {
        public static IApplicationBuilder UseMiddlewareLogic3(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<MiddlewareLogic3>();
        }
    }
}
