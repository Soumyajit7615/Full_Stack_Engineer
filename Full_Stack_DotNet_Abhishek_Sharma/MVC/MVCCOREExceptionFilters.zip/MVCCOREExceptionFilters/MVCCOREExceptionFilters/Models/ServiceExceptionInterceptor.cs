﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace MVCCOREExceptionFilters.Models
{
    public class ServiceExceptionInterceptor : ExceptionFilterAttribute, IExceptionFilter
    {
        public override void OnException(ExceptionContext context)
        {
            var error = new ErrorDetail()
            {
                StatusCode = 500,
                Message = "Something went wrong! Internal Server Error."
            };

            //Logs your technical exception with stack trace below

            context.Result = new JsonResult(error);
        }
    }
}
