﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ASPMVCWebApplicationDemo.Controllers
{
    public class CustomerPortalController : Controller
    {
        // GET: CustomerPortal
        public ActionResult Index()
        {

            return View();
        }
        public ActionResult AboutUs()
        {
            return View();
        }

        public ActionResult RazorDemo()
        {
            return View();
        }

        public ActionResult CustomerDetails()
        {
            ViewData["CustomerCode"] = 1001;
            ViewData["CustomerName"] = "Abhishek Sharma";
            ViewBag.CustomerType = "Gold Memeber";
            ViewBag.MembershipStartedDate = DateTime.Now.ToShortDateString();
            ViewData["CustomerStatus"] = true;
            ViewBag.CustomerStatus = true;
            ViewBag.CartItem =new string[]{
                "Laptop","Mouse","Speaker","Pendrive"
            };

            return View();
        }

    }
}