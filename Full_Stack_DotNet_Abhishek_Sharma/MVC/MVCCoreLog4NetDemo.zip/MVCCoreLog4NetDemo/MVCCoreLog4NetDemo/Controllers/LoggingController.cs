﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCoreLog4NetDemo.Controllers
{
    public class LoggingController : Controller
    {
        private readonly ILogger _logger;

        //public LoggingController(ILogger<LoggingController> logger)
        //{

        //    _logger = logger;
        //}


        ////For creating own categgory
        public LoggingController(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger("Logging Category");
           // _logger = logger;
        }



        public IActionResult Index()
        {
            _logger.LogTrace("Start : Getting  Trace item details ");
            _logger.LogInformation("Start : Getting Information item details ");
            _logger.LogDebug("Start : Getting debug item details ");
            _logger.LogWarning("Start : Getting  Warning item details ");
            _logger.LogCritical("Start : Getting Information item details ");
            _logger.LogError("Start : Getting debug item details ");


            List<string> list = new List<string>();
            list.Add("A");
            list.Add("B");
            list.Add("C");

            _logger.LogInformation($"Completed : Item details are { string.Join(", ", list) }");


            return View();
        }

        public IActionResult Create()
        {
            return View();
        }
    }
}
