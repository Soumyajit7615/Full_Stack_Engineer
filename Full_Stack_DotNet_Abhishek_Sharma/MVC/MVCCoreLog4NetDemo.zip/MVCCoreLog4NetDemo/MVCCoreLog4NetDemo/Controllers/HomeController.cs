﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCCoreLog4NetDemo.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCoreLog4NetDemo.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        private readonly ILogger _logger;

        public HomeController(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger("Home Category");
        }


        public IActionResult Index()
        {
            _logger.LogTrace("Start : Getting  Trace item details ");
            _logger.LogInformation("Start : Getting Information item details ");
            _logger.LogDebug("Start : Getting debug item details ");
            _logger.LogWarning("Start : Getting  Warning item details ");
            _logger.LogCritical("Start : Getting Information item details ");
            _logger.LogError("Start : Getting debug item details ");
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
