﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCoreLog4NetDemo.DAL
{
    public class Customer : IDisposable
    {
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
