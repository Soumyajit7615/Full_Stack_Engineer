﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCoreLog4NetDemo.DAL
{
    public class Employee
    {
        public int EmpCode { get; set; }
        public string EmpName { get; set; }
    }
}
