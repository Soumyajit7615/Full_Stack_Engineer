﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCORERoutingConceptsDemo.Models
{
    public class ClsCutomer
    {
        public int? CustCode { get; set; }
        public string CustName { get; set; }
        public DateTime? CustDOJ { get; set; }

    }
}
