﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVCCORERoutingConceptsDemo.Models;

namespace MVCCORERoutingConceptsDemo.Controllers
{
    [Route("CustomerPortalar")]
    public class CustomerController : Controller
    {
        static List<ClsCutomer> Customers = new List<ClsCutomer>()
        {
            new ClsCutomer()
            {
                CustCode = 1001,
                CustName ="Abhee",
                CustDOJ = new DateTime(2021,10,5)

            },
             new ClsCutomer()
            {
                CustCode = null,
                CustName ="Anurag",
                CustDOJ = null

            },
              new ClsCutomer()
            {
                CustCode = 1003,
                CustName ="Harish",
                CustDOJ = DateTime.Now

            }
        };

        // GET: CustomerController
        [Route("Customers")]
        public ActionResult Index()
        {
            var CustomerList = Customers.ToList();
            return View(CustomerList);
        }

        [HttpGet]
        public IActionResult AddCutomer()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddCutomer(ClsCutomer clsCutomer)
        {
            Customers.Add(clsCutomer);
            //return RedirectToAction("CustomerDetails", clsCutomer);
            return View("CustomerDetails", clsCutomer);
        }
        [HttpGet]
        public IActionResult CustomerDetails(ClsCutomer clsCutomer)
        {

            ClsCutomer cust = Customers.FirstOrDefault(x => x.CustCode == clsCutomer.CustCode);

            return View(cust);
        }

        [HttpGet]
        public IActionResult CustomerDetailsWithid(int? id)
        {

            ClsCutomer cust = Customers.FirstOrDefault(x => x.CustCode == id);

            return View(cust);
        }

        [HttpGet]
        public IActionResult CustomerDetailsWithRegularExpression(string custid)
        {
            int id = 1001;

            ClsCutomer cust = Customers.FirstOrDefault(x => x.CustCode == id);

            return View(cust);
        }
    }
}
