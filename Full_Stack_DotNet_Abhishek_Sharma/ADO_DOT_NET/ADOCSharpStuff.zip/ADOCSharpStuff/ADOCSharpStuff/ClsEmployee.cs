﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADOCSharpStuff
{
    // DAL | POCO : PLAIN OLD CLR OBJECT
    class ClsEmployee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public int DeptID { get; set; }

    }
}
