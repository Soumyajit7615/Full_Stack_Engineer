﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadConceptsStuff
{
    class ThreadBackgroundAndJoinRevison
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main thread started :");
            ThreadStart ts1 = new ThreadStart(Process1);
            
            Thread t1 = new Thread(ts1);
            t1.IsBackground = true;
        
            t1.Priority = ThreadPriority.Highest;
            
            t1.Start();

            t1.Join();

            //Thread t2 = new Thread(new ThreadStart(Process2));
            //t2.Priority = ThreadPriority.AboveNormal;
           
            //t2.Start();
            //t2.Join();
            //Thread t3 = new Thread(new ThreadStart(Process3));
            //t3.Priority = ThreadPriority.Normal;
            //t3.Start();
            Console.WriteLine("Main thread ended :");


        }
        public static void Process1()
        {
            Console.WriteLine("I am process I:");
            Console.WriteLine("I will generate no. from 1 to 100000000000");
            for (double i = 1; i <= 100000000000; i++)
            {
                //Thread.Sleep(500);
                Console.WriteLine(i);
            }

        }
        public static void Process2()
        {
            Console.WriteLine("I am process II:");
            //Console.ReadLine();

            Console.WriteLine("I will generate no. from 999 to 899");
            for (int i = 999; i >= 899; i--)
            {
                Console.WriteLine(i);
            }


        }

        public static void Process3()
        {
            Console.WriteLine("I am process III:");
            Console.WriteLine("I will generate no. from 500 to 399");
            for (int i = 500; i >= 399; i--)
            {
                Console.WriteLine(i);
            }


        }
    }
}
