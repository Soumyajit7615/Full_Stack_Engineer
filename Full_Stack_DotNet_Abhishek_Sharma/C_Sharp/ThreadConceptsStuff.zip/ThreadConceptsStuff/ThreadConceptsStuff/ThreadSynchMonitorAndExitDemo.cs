﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    class ThreadSynchMonitorAndExitDemo
    {
        static void Main(string[] args)
        {
            Account HDFC = new Account();
            
            ParameterizedThreadStart pthobj = new ParameterizedThreadStart(HDFC.Withdraw);
            Thread th1 = new Thread(pthobj);
            Thread th2 = new Thread(pthobj);
            th1.Priority = ThreadPriority.Lowest;
            th1.Start(1000.00m);
            th2.Priority = ThreadPriority.Highest;
            th2.Start(10000.00m);
        }
    }
}
