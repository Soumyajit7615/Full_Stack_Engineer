﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    class ThreadDemoRevision
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Main thread started :");
            Task1();
            ThreadStart ts1 = new ThreadStart(Process1);
            Thread t1 = new Thread(ts1);
            t1.Start();
            Task2();
            ThreadStart ts2 = new ThreadStart(Process2);
            Thread t2 = new Thread(ts2);
            t2.Start();

            ThreadStart ts3 = new ThreadStart(Process3);
            Thread t3 = new Thread(ts3);
            t3.Start();
            Task3();
            Console.WriteLine("Main thread Ended :");




        }

        public static void Task1()
            {
            Console.WriteLine("I am task 1");
            Thread.Sleep(1000);
            }
        public static void Task2()
        {
            Console.WriteLine("I am task 2");
            Thread.Sleep(1000);
        }
        public static void Task3()
        {
            Console.WriteLine("I am task 3");
            Thread.Sleep(1000);
        }

        public static void Process1()
        {
            Console.WriteLine("I am process I:");
            Console.WriteLine("I will generate no. from 1 to 100");
            for (int i = 1; i <= 100; i++)
            {
                //Thread.Sleep(500);
                Console.WriteLine(i);
            }

        }
        public static void Process2()
        {
            Console.WriteLine("I am process II:");
            //Console.ReadLine();

            Console.WriteLine("I will generate no. from 999 to 899");
            for (int i = 999; i >= 899; i--)
            {
                Console.WriteLine(i);
            }


        }

        public static void Process3()
        {
            Console.WriteLine("I am process III:");
            Console.WriteLine("I will generate no. from 500 to 399");
            for (int i = 500; i >= 399; i--)
            {
                Console.WriteLine(i);
            }


        }


    }
}
