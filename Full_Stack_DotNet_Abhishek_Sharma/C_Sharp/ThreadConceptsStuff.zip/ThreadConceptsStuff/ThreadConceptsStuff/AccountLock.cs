﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    class AccountLock
    {
        private object thisLock = new object();
        int balance;
        Random r = new Random();
        public AccountLock(int ini)
        {
            balance = ini;
        }
        int WithDraw(int amount)
        {
            if (balance < 0)
            {

                throw new Exception("Insufficient balance");
            }
            lock (thisLock)
            {

                if (balance >= amount)
                {

                    Console.WriteLine("\n");
                    
                    Console.WriteLine("Balance before the withdrawal :" + balance);
                    Console.WriteLine("Amount to withdraw :" + amount);
                    balance = balance - amount;
                    Console.WriteLine("Balance After the withdrawal :" + balance);
                    return amount;
                }
                else
                {
                    return 0;
                }
            }

        }
        public void DoTransaction()
        {
           
            for (int i = 0; i < 100; i++)
            {
                WithDraw(r.Next(1, 100));
               
            }
        }

    }
}
