﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    class ThreadBackgroundAndJoin
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main thread started :");
            ThreadStart th = new ThreadStart(ProcessI);
            Thread th1 = new Thread(th);
            th1.IsBackground = true;
            th1.Start();
            th1.Join();
            Console.WriteLine("Main thread ended");
        }
        public static void ProcessI()
        {
            for (int i = 1; i <= 100; i++)
            {
                Thread.Sleep(100);
                Console.WriteLine(i);

            }
        }
    }
}
