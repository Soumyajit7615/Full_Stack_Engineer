﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    class ThreadLockDemo
    {
        static void Main(string[] args)
        {

            Thread[] Persons = new Thread[10];
            AccountLock ATM = new AccountLock(1000);
            for (int i = 0; i < 10; i++)
            {
                Thread t = new Thread(new ThreadStart(ATM.DoTransaction));
                Persons[i] = t;
                Persons[i].Name = "Person" + i + 1;

            }
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(1000);
                
                Persons[i].Start();

            }


        }
    }
}
