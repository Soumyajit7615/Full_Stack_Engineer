﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    static class MyClass
    {
        static MyClass()
        {

        }
        static public void Show(object obj)
        {
            Console.WriteLine("Hello i am from Myclass:"+obj);
        }

    }
    class ParameterizedThreadDemo
    {
        static void Main(string[] args)
        {
            int[] IntArray = new int[5];
           
            int[] IntArray2 = { 12, 23, 4, 55, 45 };



            ParameterizedThreadStart pt = new ParameterizedThreadStart(MyClass.Show);
            Thread th = new Thread(pt);
            th.Name = "MyThread";
            th.Start("Wake up thread");


            //Thread thread = new Thread(Process1);
            //thread.Start();

            Thread newThread;
            ParameterizedThreadStart ptsth = new ParameterizedThreadStart(DoWork);
            for (int i = 1; i < 4; i++)
            {
                Console.WriteLine("Thread : {0}", i);
                newThread = new Thread(ptsth);
                newThread.Name = i.ToString();
                newThread.Start(5);
            }
        }
        public static void DoWork(object iteration)
        {
            for (int counter = 1; counter <= (int)iteration; counter++)
            {
                Console.WriteLine("Thread {0} Iteration {1}", Thread.CurrentThread.Name, counter);
                Thread.Sleep(2000);
            }
        }
        public static void Process1()
        {
            Console.WriteLine("I am process I:");
            Console.WriteLine("I will generate no. from 1 to 100");
            for (int i = 1; i <= 100; i++)
            {
                //Thread.Sleep(500);
                Console.WriteLine(i);
            }

        }
    }
}
