﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    class ThreadPoolDemo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main thread started:");
            ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadProcI));
            ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadProcII));
            Thread.Sleep(1000);
            Console.WriteLine("Main thread Ended:");

        }
        public static void ThreadProcI(object obj)
        {
            Console.WriteLine("I am from thread pool,i will generate no from 1 to 20");
            for (int i = 1; i <= 20; i++)
            {
                Console.WriteLine(i);

            }
        }
        public static void ThreadProcII(object obj)
        {
            Console.WriteLine("I am from thread pool,i will generate no from 900 to 880");
            for (int i = 900; i >= 880; i--)
            {
                Console.WriteLine(i);
            }
        }
    }
}
