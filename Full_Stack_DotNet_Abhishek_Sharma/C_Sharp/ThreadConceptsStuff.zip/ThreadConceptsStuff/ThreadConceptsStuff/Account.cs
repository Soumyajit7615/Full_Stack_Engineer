﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadConceptsStuff
{
    class Account
    {
        decimal balance;
        public Account()
        {
            balance = 25000;
        }
        public void Withdraw(object amt)
        {

            decimal amount = (decimal)amt;
            try
            {
                Monitor.Enter(typeof(Account));
                if (this.balance >= amount)
                {
                    this.balance -= amount;
                    DateTime transactiontime = DateTime.Now;
                    Thread.Sleep(2000);
                    this.AddTransaction(amount, transactiontime, "YES");

                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            finally
            {

                Monitor.Exit(typeof(Account));
                Console.WriteLine("finally");
            }

        }
        public void AddTransaction(decimal amount, DateTime transtime, string p)
        {
            Console.WriteLine("Your current balance is : {0}", balance);
            Console.WriteLine("After amount transac : {0}", amount);
            Console.WriteLine("Transaction has been made on :{0}", transtime);
            Console.WriteLine("Transaction successfull :{0}", p);

        }

    }
}
