﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyLogDetailsServices
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (!File.Exists(@"F:\CTSDEMO\Log.txt"))
            {
                File.Create(@"F:\CTSDEMO\Log.txt");
            }
            using (StreamWriter sw = new StreamWriter(@"F:\CTSDEMO\Log.txt", true))
            {
                sw.WriteLine($"Service starts at : {DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt")}");

            }
        }

        protected override void OnStop()
        {
            using (StreamWriter sw = new StreamWriter(@"F:\CTSDEMO\Log.txt", true))
            {
                sw.WriteLine($"Service stops at : {DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt")}");

            }
        }
    }
}
