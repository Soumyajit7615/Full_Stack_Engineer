﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmployeeRegistrationWindowsFormsApp
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        SqlCommandBuilder cmb;
        DataSet ds;
        DataTable dt;
        static int indx;
        public Form1()
        {
            InitializeComponent();
        }
        private void ClearTextBoxes()
        {
            txtEmpID.Clear();
            txtEmpName.Clear();
            txtDeptId.Clear();
            txtSalary.Clear();


        }

        private void ComboBoxUpdate()
        {

            int count = 0;
            cmbempid.Items.Clear();
            while (count < ds.Tables["JustEmployee"].Rows.Count)
            {
                cmbempid.Items.Add(ds.Tables["JustEmployee"].Rows[count][0].ToString());
                count++;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            con = new SqlConnection(@"Data Source=DESKTOP-BLC9DN3\MSSQLSERVER1;Initial Catalog=CTSREPODATA;Integrated Security=true");
            da = new SqlDataAdapter("select * from Employee", con);
            cmb = new SqlCommandBuilder(da);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            ds = new DataSet();
            da.Fill(ds, "JustEmployee");
            dataGridView1.DataSource = ds.Tables["JustEmployee"];
            btnFirstRecord.PerformClick();
            indx = 0;

            ComboBoxUpdate();

        }

        private void btnAddRecord_Click(object sender, EventArgs e)
        {
            if (txtEmpName.Text != "" && txtDeptId.Text != "" && txtSalary.Text != "")
            {


                DataRow drow = ds.Tables["JustEmployee"].NewRow();
                drow[1] = txtEmpName.Text;
                drow[2] = Convert.ToInt32(txtDeptId.Text);
                drow[3] = Convert.ToInt32(txtSalary.Text);
                ds.Tables["JustEmployee"].Rows.Add(drow);
                da.Update(ds, "JustEmployee");
                lblStatus.Text = "STATUS : ONE RECORD ADDED";
                ClearTextBoxes();
                btnClearText.PerformClick();
                ComboBoxUpdate();
            }
            else
            {
                lblStatus.Text = "text boxes are empty";

            }

        }

        private void btnClearText_Click(object sender, EventArgs e)
        {
            txtEmpID.Clear();
            txtEmpID.Text = "";
            txtEmpName.Clear();
            txtDeptId.Clear();
            txtSalary.Clear();

        }

        private void btnFirstRecord_Click(object sender, EventArgs e)
        {
            txtEmpID.Text = ds.Tables["JustEmployee"].Rows[0][0].ToString();
            txtEmpName.Text = ds.Tables["JustEmployee"].Rows[0][1].ToString();
            txtDeptId.Text = ds.Tables["JustEmployee"].Rows[0][2].ToString();
            txtSalary.Text = ds.Tables["JustEmployee"].Rows[0][3].ToString();

            lblStatus.Text = "STATUS : SHOWING FIRST RECORD";
            indx = 0;
        }

        private void btnNextRecord_Click(object sender, EventArgs e)
        {
            indx++;
            if (indx >= 0 && indx < ds.Tables["JustEmployee"].Rows.Count)
            {


                txtEmpID.Text = ds.Tables["JustEmployee"].Rows[indx][0].ToString();
                txtEmpName.Text = ds.Tables["JustEmployee"].Rows[indx][1].ToString();
                txtDeptId.Text = ds.Tables["JustEmployee"].Rows[indx][2].ToString();
                txtSalary.Text = ds.Tables["JustEmployee"].Rows[indx][3].ToString();
                lblStatus.Text = "STATUS : SHOWING NEXT RECORD";

            }
            else
            {
                indx = 0;
            }

        }

        private void btnPreviousRecord_Click(object sender, EventArgs e)
        {
            indx--;
            if (indx >= 0 && indx < ds.Tables["JustEmployee"].Rows.Count)
            {


                txtEmpID.Text = ds.Tables["JustEmployee"].Rows[indx][0].ToString();
                txtEmpName.Text = ds.Tables["JustEmployee"].Rows[indx][1].ToString();
                txtDeptId.Text = ds.Tables["JustEmployee"].Rows[indx][2].ToString();
                txtSalary.Text = ds.Tables["JustEmployee"].Rows[indx][3].ToString();
                lblStatus.Text = "STATUS : SHOWING REVIOUS RECORD";

            }
            else
            {
                indx = ds.Tables["JustEmployee"].Rows.Count;


            }

        }

        private void btnLastRecord_Click(object sender, EventArgs e)
        {
            indx = ds.Tables["JustEmployee"].Rows.Count - 1;

            txtEmpID.Text = ds.Tables["JustEmployee"].Rows[indx][0].ToString();
            txtEmpName.Text = ds.Tables["JustEmployee"].Rows[indx][1].ToString();
            txtDeptId.Text = ds.Tables["JustEmployee"].Rows[indx][2].ToString();
            txtSalary.Text = ds.Tables["JustEmployee"].Rows[indx][3].ToString();
            lblStatus.Text = "STATUS : SHOWING LAST RECORD";

        }

        private void cmbempid_SelectedIndexChanged(object sender, EventArgs e)
        {
            int EmpID = Convert.ToInt32(cmbempid.SelectedItem.ToString());

            DataRow drow = ds.Tables["JustEmployee"].Rows.Find(EmpID);
            if (drow != null)
            {
                txtEmpID.Text = drow[0].ToString();
                txtEmpName.Text = drow[1].ToString();
                txtDeptId.Text = drow[2].ToString();
                txtSalary.Text = drow[3].ToString();


            }

        }

        private void btnDeleteRecord_Click(object sender, EventArgs e)
        {
            int EmpID = Convert.ToInt32(txtEmpID.Text.ToString());

            ds.Tables["JustEmployee"].Rows.Find(EmpID).Delete();

            da.Update(ds, "JustEmployee");
            ComboBoxUpdate();
            ClearTextBoxes();
            lblStatus.Text = "STATUS : RECORD DELETED SUCCESSFULLY";

        }

        private void btnUpdateRecord_Click(object sender, EventArgs e)
        {
            int EmpID = Convert.ToInt32(txtEmpID.Text.ToString());

            DataRow drow = ds.Tables["JustEmployee"].Rows.Find(EmpID);
            if (drow != null)
            {


                drow[1] = txtEmpName.Text;
                drow[2] = txtDeptId.Text;
                drow[3] = txtSalary.Text;


            }
            
            da.Update(ds, "JustEmployee");
            ComboBoxUpdate();
            ClearTextBoxes();
            lblStatus.Text = "STATUS : RECORD UPDATED SUCCESSFULLY";
        }
    }
}
