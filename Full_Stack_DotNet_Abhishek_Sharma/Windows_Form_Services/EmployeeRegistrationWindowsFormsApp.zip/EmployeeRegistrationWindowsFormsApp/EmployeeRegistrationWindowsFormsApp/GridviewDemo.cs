﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmployeeRegistrationWindowsFormsApp
{
    public partial class GridviewDemo : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        SqlCommandBuilder cmb;
        DataSet ds;
        DataTable dt;
        static int flag = 0;
        public GridviewDemo()
        {
            InitializeComponent();
        }

        private void GridviewDemo_Load(object sender, EventArgs e)
        {
           

            con = new SqlConnection(@"Data Source=DESKTOP-BLC9DN3\MSSQLSERVER1;Initial Catalog=CTSREPODATA;Integrated Security=true");
            da = new SqlDataAdapter("select * from Employee", con);
            cmb = new SqlCommandBuilder(da);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            ds = new DataSet();
            da.Fill(ds, "JustEmployee");
            da = new SqlDataAdapter("select * from Department", con);
            cmb = new SqlCommandBuilder(da);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
           
            da.Fill(ds, "JustDepartment");
            dataGridView1.DataSource = ds.Tables["JustEmployee"];
            btnShowData.Text = "Department";
        }

        private void btnShowData_Click(object sender, EventArgs e)
        {
            if (flag==0)
            {
                dataGridView1.DataSource = ds.Tables["JustEmployee"];
                btnShowData.Text = "Department";
                flag = 1;
            }
            else
            {
                dataGridView1.DataSource = ds.Tables["JustDepartment"];
                btnShowData.Text = "Employee";
                flag = 0;
            }
        }
    }
}
