﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Timers;

namespace ProcessKillService
{
    public partial class ProcessKill : ServiceBase
    {
        public ProcessKill()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {

            // TODO: Add code here to start your service.
            Timer T1 = new Timer();
            T1.Interval = (1000);
            T1.AutoReset = true;
            T1.Enabled = true;
            T1.Start();
            T1.Elapsed += new System.Timers.ElapsedEventHandler(T1_Elapsed);



            if (!File.Exists(@"F:\CTSDEMO\KillLog.txt"))
            {
                File.Create(@"F:\CTSDEMO\KillLog.txt");
            }
            using (StreamWriter sw = new StreamWriter(@"F:\CTSDEMO\KillLog.txt", true))
            {
                sw.WriteLine("Killing process Service starts at : {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));

            }
            timer1.Enabled = true;
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            Timer T1 = new Timer();
            T1.Interval = (1000);
            T1.AutoReset = true;
            T1.Enabled = true;
            T1.Start();
            T1.Elapsed += new System.Timers.ElapsedEventHandler(T1_Elapsed);
            using (StreamWriter sw = new StreamWriter(@"F:\CTSDEMO\KillLog.txt", true))
            {
                sw.WriteLine("Killing process Service stops : {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));

            }
            timer1.Enabled = false;
        }
        private void T1_Elapsed(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter(@"F:\CTSDEMO\KillLog.txt", true))
            {
                sw.WriteLine("Checking Process: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));

            }
            Process[] runingProcess = Process.GetProcesses();
            for (int i = 0; i < runingProcess.Length; i++)
            {
                //Console.WriteLine(runingProcess[i].ProcessName);

                // compare equivalent process by their name
                if (runingProcess[i].ProcessName == "mspaint")
                {
                    // kill  running process
                    runingProcess[i].Kill();
                }

            }
        }
    }
}
