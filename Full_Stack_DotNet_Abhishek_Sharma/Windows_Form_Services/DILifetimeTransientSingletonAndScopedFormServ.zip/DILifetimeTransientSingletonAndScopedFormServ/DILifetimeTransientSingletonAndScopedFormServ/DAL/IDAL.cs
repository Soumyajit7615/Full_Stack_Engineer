﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DILifetimeTransientSingletonAndScopedFormServ.DAL
{
    public interface IDAL
    {
        string MyGuid { get; set; }
        string myConType { get; set; }
        void CustomerAdd();
        void CustomerDetails();
        void CustomerUpdate();
        void CustomerDelete();
    }
}
