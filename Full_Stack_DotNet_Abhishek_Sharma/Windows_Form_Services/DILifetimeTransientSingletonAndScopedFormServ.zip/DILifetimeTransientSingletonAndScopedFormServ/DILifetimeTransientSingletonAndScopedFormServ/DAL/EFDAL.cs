﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DILifetimeTransientSingletonAndScopedFormServ.DAL
{
    
    public class EFDAL : IDAL
    {
        public string MyGuid { get; set; }
        public string myConType { get; set; }


        public EFDAL()
        {
            this.MyGuid = Guid.NewGuid().ToString();
            this.myConType = "EF DATA CONNECTION";
        }


        public void CustomerAdd()
        {

            throw new NotImplementedException();
        }

        public void CustomerDelete()
        {
            throw new NotImplementedException();
        }

        public void CustomerDetails()
        {
            throw new NotImplementedException();
        }

        public void CustomerUpdate()
        {
            throw new NotImplementedException();
        }
    }
}
