﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DILifetimeTransientSingletonAndScopedFormServ.Models
{
    public class SilverCustomer : Customer
    {
        public int CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public double CustomerAmount { get; set; }
        public string CustomerType { get; set; } = "SILVER";
        public bool FreeMeal { get; set; } = false;
    }
}
