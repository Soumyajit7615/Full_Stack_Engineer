﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DILifetimeTransientSingletonAndScopedFormServ.Models
{
    public class GoldCustomer : Customer
    {
        public int CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public double CustomerAmount { get; set; }
        public string CustomerType { get; set; } = "GOLD";
        public bool FreeMeal { get; set; } = true;
    }
}
