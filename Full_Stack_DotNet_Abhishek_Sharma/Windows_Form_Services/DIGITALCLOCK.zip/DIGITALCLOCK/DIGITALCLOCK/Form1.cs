﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIGITALCLOCK
{
    public partial class Form1 : Form
    {
        static int flag = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            label1.Text = DateTime.Now.ToString("hh:mm:ss tt");
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("hh:mm:ss tt");

        }

        private void btntoggleButton_Click(object sender, EventArgs e)
        {
            if (flag==1)
            {
                timer1.Enabled = false;
                flag = 0;
                btntoggleButton.Text = "START";
            }
            else
            {
                timer1.Enabled = true;
                flag = 1;
                btntoggleButton.Text = "STOP";

            }

        }
    }
}
