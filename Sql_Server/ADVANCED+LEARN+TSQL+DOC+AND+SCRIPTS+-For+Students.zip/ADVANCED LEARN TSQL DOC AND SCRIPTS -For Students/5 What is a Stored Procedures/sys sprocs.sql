sp_help	

sp_helptext	

sp_spaceused
	
sp_who	

sp_depends

