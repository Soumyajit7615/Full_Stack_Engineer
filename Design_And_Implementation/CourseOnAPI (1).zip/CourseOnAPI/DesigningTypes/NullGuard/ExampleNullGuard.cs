﻿using System;
using System.Threading;

namespace DesigningTypes.NullGuard {
    public class Customer {
        public void Pay(Payment p, CustomerName customerName) {         
        }
    }

    public class CustomerName {}

    public class Payment {
    }
}