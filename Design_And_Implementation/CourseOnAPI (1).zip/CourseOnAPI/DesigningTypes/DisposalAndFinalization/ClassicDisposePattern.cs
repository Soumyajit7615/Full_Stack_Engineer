﻿using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace DesigningTypes.DisposalAndFinalization {
    public class ResourceHolder : IDisposable {
        private readonly IntPtr unmanagedResource;
        private readonly SafeHandle managedResource;

        public ResourceHolder() {
            unmanagedResource = Marshal.AllocHGlobal(sizeof (int));
            managedResource = new SafeFileHandle(new IntPtr(), true);
        }

        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool isManualDisposing) {
            ReleaseUnmanagedResourse(unmanagedResource);
            if (isManualDisposing) {
                ReleaseManagedResources(managedResource);
            }
        }

        private void ReleaseManagedResources(SafeHandle safeHandle) {
            if (safeHandle != null) {
                safeHandle.Dispose();
            }
        }

        private void ReleaseUnmanagedResourse(IntPtr intPtr) {
            Marshal.FreeHGlobal(intPtr);
        }

        ~ResourceHolder() {
            Dispose(false);
        }
    }
}