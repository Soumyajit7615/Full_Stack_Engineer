﻿
using NullGuard;

[assembly: NullGuard(ValidationFlags.All)]

namespace DesigningTypes
{
    class Initer
    {
    }
}
