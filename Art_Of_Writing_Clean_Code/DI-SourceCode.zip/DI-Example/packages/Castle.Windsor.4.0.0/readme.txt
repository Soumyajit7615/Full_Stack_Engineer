Thanks for downloading this Castle Windsor package.
You can find full list of changes in CHANGELOG.md

Documentation:		- http://www.castleproject.org/projects/windsor/
Discusssion group: 	- http://groups.google.com/group/castle-project-users
StackOverflow tags:	- castle-windsor, castle

Issue tracker: 		- http://issues.castleproject.org/dashboard
