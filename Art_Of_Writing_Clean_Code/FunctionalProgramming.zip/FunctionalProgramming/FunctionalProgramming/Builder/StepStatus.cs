﻿namespace FunctionalProgramming.Builder
{
    public enum StepStatus
    {
        Met,
        AlmostMet,
        NotEvenClose
    }
}