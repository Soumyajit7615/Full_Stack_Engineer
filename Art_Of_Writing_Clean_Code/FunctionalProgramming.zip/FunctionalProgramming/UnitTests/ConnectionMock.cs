﻿using FunctionalProgramming.Builder;

namespace UnitTests
{
    public class ConnectionMock : IConnection
    {
        public void Connect()
        {
            
        }
    }
}