namespace SOLID.OCP
{
    public enum DeviceModel
    {
        CoinDispenserCube4,
        CoinDispsenerSch2,
        CoinAccepterNri,
        BillAccepterCashCode,
        BillDispenserEcdm
    }
}