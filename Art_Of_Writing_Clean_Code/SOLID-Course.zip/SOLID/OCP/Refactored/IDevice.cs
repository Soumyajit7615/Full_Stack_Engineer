﻿namespace SOLID.OCP.Refactored
{
    public interface IDevice
    {
        string Find();
    }   
}
