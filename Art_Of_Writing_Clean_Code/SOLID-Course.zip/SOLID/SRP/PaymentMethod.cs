namespace SOLID.SRP
{
    public enum PaymentMethod
    {
        CreditCard,
        Cash
    }
}