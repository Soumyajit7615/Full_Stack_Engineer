namespace SOLID.SRP
{
    public class PaymentDetails
    {
        public PaymentMethod Method { get; set; }
    }
}