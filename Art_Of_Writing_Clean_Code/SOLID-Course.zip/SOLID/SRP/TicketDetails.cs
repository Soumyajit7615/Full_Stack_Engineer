namespace SOLID.SRP
{
    public class TicketDetails
    {
        public decimal Price { get; set; }
    }
}