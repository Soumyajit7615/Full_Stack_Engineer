﻿namespace ContactWebEFCore6.Models
{
    public class ContactCacheConstants
    {
        public const string ALL_STATES = "cache_all_states_data";
    }
}
