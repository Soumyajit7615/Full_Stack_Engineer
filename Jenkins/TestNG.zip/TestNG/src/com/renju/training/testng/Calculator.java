package com.renju.training.testng;

public class Calculator {
	// Method to add 2 numbers
	public int addNumbers(int numberOne, int numberTwo) {
		return numberOne + numberTwo;
	}
	// Method to subtract 2 numbers
	public int subtractNumbers(int numberOne, int numberTwo) {
		return numberOne - numberTwo;
	}
}
